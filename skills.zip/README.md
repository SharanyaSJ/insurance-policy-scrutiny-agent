Skills — modular processors used by the orchestrator.

Purpose
- Provide a clear, programmatic contract for each capability the agent can use: extraction, comparison, ingestion, reporting, HITL, memory, and KB.
- Each skill lives under INSURANCE_POLICY_SCRUTINY_AGENT/skills/<skill_name>/ and exposes a SKILL.md that documents its contract.
- Skills MUST read inputs from INSURANCE_POLICY_SCRUTINY_AGENT/input/<Company>/ and write outputs only to INSURANCE_POLICY_SCRUTINY_AGENT/output/<Company>/ or approved outputs under INSURANCE_POLICY_SCRUTINY_AGENT/output/.

Available skills (summary)

1) pdf_rfp
- Purpose: Extract structured fields and clauses from RFP documents (PDF/DOCX), detect contradictions and ambiguous language, and prepare HITL briefs.
- Key inputs: RFP document file
- Key outputs: extraction JSON, rfp brief (markdown)
- Primary files: <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/pdf_rfp/SKILL.md</file_path>SKILL.md (pdf_rfp)</file>

2) quote_sheet
- Purpose: Ingest insurer Quote Sheets, extract coverages, premiums, deviations, and produce a quote brief for HITL; includes conservative (vA) and aggressive (vB) extraction modes.
- Key inputs: Quote document file
- Key outputs: quote extraction JSON, quote brief, staged extraction artifacts
- Primary files: <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/quote_sheet/SKILL.md</file_path>SKILL.md (quote_sheet)</file>

3) rfp_quote_compare
- Purpose: Clause-level mapping and deterministic comparison of RFP vs Quote; produces validation flags, mapping_table, and a comparison report for HITL.
- Key inputs: RFP extraction JSON, Quote extraction JSON
- Key outputs: comparison_report.json, mapping_table.json, candidate flags
- Primary files: <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/rfp_quote_compare/SKILL.md</file_path>SKILL.md (rfp_quote_compare)</file>

4) policy_document_ingestion
- Purpose: Orchestrates multi-file policy ingestion (extractors, merger, validation) producing a canonical policy JSON and provenance logs.
- Key inputs: Policy package (docx/pdf/addenda)
- Key outputs: canonical policy JSON, merge logs, staging manifest
- Primary files: <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/policy_document_ingestion/SKILL.md</file_path>SKILL.md (policy_document_ingestion)</file>

5) three_way_comparison
- Purpose: Align fields from RFP, Quote, and Policy; run normalization, validation, drift detection and assemble a compliance_matrix and drift_report.
- Key inputs: rfp_extraction.json, quote_extraction.json, policy_canonical.json
- Key outputs: mapping_table.json, compliance_matrix.json, drift_report.json
- Primary files: <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/three_way_comparison/SKILL.md</file_path>SKILL.md (three_way_comparison)</file>

6) final_reporting
- Purpose: Generate the auditable final report (JSON/markdown/PDF) from comparison outputs, compute risk aggregation and produce final verdicts for stakeholders.
- Key inputs: compliance_matrix.json, drift_report.json, mapping_table.json
- Key outputs: final_report_vN.json, final_report_vN.md, optional PDF/DOCX
- Primary files: <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/final_reporting/SKILL.md</file_path>SKILL.md (final_reporting)</file>

7) hitl
- Purpose: Human-in-the-loop enforcement for any write action to memory or storage; records structured decisions and enforces confirmation workflows.
- Key inputs: candidate write plans, briefs
- Key outputs: decision JSONs (case decisions), audit entries, authorized writes
- Primary files: <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/hitl/SKILL.md</file_path>SKILL.md (hitl)</file>

8) memory
- Purpose: Schemas and helpers for append-only project memory (global, company, case); validates candidate writes and enforces naming/version rules.
- Key inputs: candidate memory JSONs from skills
- Key outputs: immutable _vN JSON records in memory/, audit logs
- Primary files: <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/memory/SKILL.md</file_path>SKILL.md (memory)</file>

9) knowledge_loop
- Purpose: Learning updater and KB retriever for saving validated precedents and retrieving them for future cases; includes schema validation and citation tagging.
- Key inputs: confirmed case outcomes and candidate KB entries
- Key outputs: KB entries (immutable), retriever results with citation_tag
- Primary files: <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/knowledge_loop/SKILL.md</file_path>SKILL.md (knowledge_loop)</file>

Utilities & templates
- enforce_paths helper: INSURANCE_POLICY_SCRUTINY_AGENT/tools/enforce_paths.py — ensure input/output folders, safe move and write helpers (<file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/tools/enforce_paths.py</file_path>enforce_paths.py</file>)
- strict compliance template: INSURANCE_POLICY_SCRUTINY_AGENT/skills/utils/STRICT_COMPLIANCE_TEMPLATE.md — canonical flagging output and FLAGGING_RULES (<file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/utils/STRICT_COMPLIANCE_TEMPLATE.md</file_path>STRICT_COMPLIANCE_TEMPLATE.md</file>)

Guidance for dynamic discovery
- To discover available skills at runtime the orchestrator/agent should:
  1) List folders under INSURANCE_POLICY_SCRUTINY_AGENT/skills/
  2) For each folder, load <folder>/SKILL.md to learn: Overview, When to use, Inputs, Outputs, Failure modes
  3) Validate the skill exposes expected entry points (e.g., read_extract, compare, map) before invoking

Examples of important files to inspect programmatically
- Orchestrator: <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/orchestrator.py</file_path>orchestrator.py</file>
- Memory schemas: <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/memory/schemas</file_path>skills/memory/schemas</file>

Contact/Owner
- The orchestrator remains the canonical entrypoint. See: <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/orchestrator.py</file_path>orchestrator.py</file>
