---
name: final-reporting
description: "Generate standardized final reports and findings from comparison artifacts (compliance matrix, drift report) with consistent format and outputs. Includes upstream/downstream and failure modes."
license: Proprietary
---

# Final Reporting & Findings Skill

## Overview
Creates formal, auditable final reports from comparison artifacts (compliance_matrix, drift_report, mapping_table) and produces pass/fail verdicts, deviation summaries, and clause-level findings.

## When to use
- After three-way comparison artifacts are available and HITL approvals (if required) are in place.

## Upstream / Downstream
- Upstream: three_way_comparison outputs (compliance_matrix.json, drift_report.json, mapping_table.json), company config
- Downstream: HITL (for confirmation), memory (case record), archival storage, stakeholder delivery (email, S3)

## Core steps
1) Aggregate comparison artifacts and compute summary metrics
2) Generate deviation and clause-level findings with evidence snippets
3) Compute risk aggregation using company risk weights
4) Produce final pass/fail verdict with rationale and rule traceability
5) Render outputs: JSON, markdown, optional PDF/DOCX and presentation slides
6) Present to HITL if persistence or stakeholder distribution is requested

## Outputs
- final_report_vN.json (structured)
- final_report_vN.md (human-readable brief)
- final_report_vN.pdf (optional)

## Failure modes (detection & mitigation)
- missing_artifact: required comparison artifact missing → abort with clear error and require upstream re-run
- inconsistent_summaries: aggregation mismatch (counts don't sum) → create an integrity report and require human reconciliation
- rendering_errors (PDF/DOCX): fallback to delivering markdown and attach rendering logs
- PII_redaction_failure: if redaction fails, fail safe by presenting a redacted copy and escalating to HITL
- persistence_failure: retry writes and alert; do not mark report as final until persisted successfully

## QA & checks
- Validate final_report.json against report templates/schemas
- Confirm audit.log entry with provenance for final verdicts
- Require HITL signoff for distribution to external stakeholders or regulatory filings

## Developer notes
- Maintain a clear mapping between each reported finding and the underlying mapping_table row id and evidence snippet for traceability.
