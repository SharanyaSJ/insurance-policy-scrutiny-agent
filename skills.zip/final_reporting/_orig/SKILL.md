---
name: final-reporting
description: "Generate standardized final reports and findings from comparison artifacts (compliance matrix, drift report) with consistent format and outputs."
license: Proprietary
---

# Final Reporting & Findings Skill

## Overview
This skill creates formal, auditable final reports from comparison artifacts (Final Compliance Matrix, drift_report, mapping_table) and produces pass/fail verdicts, deviation summaries, risk reports, and clause-level findings. Reports follow a consistent structure for human reviewers and archival.

## When To Use
- After three-way comparison artifacts (compliance_matrix.json, drift_report.json) are produced.
- Before persisting final verdicts to memory or sending reports to stakeholders.

## Step By Step Process
1. Inputs
   - Required: compliance_matrix.json, drift_report.json, mapping_table.json
   - Optional: company config, case_id, policy_id
   - Example input paths:
   ```
   INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/<COMPANY_ID>/policies/<POLICY_ID>/comparison/compliance_matrix.json
   ```
2. Aggregate results
   - Summarize per-field final_status counts (PASS/FAIL/REQUIRES_REVIEW) and compute overall pass_rate.
3. Produce Deviation Summary
   - List fields that failed or require review with short evidence snippets and page refs where available.
4. Produce Risk Report
   - Use per-field drift_score and company risk weights to aggregate a risk score and map to risk levels (Low/Medium/High/Critical).
5. Clause-level findings
   - Produce a clause-level table: clause_id, rfp_text_snippet, quote_text_snippet, policy_text_snippet, finding (ok/changed/removed/added), confidence.
6. Final Pass / Fail verdict
   - Apply company policy for pass criteria (e.g., no critical fails and pass_rate >= configured threshold). Output final_pass_fail boolean and rationale.
7. Output formats & storage
   - Save report as structured JSON and human-readable markdown and PDF (optional) under:
   ```
   INSURANCE_POLICY_SCRUTINY_AGENT/output/reports/<COMPANY_ID>/<POLICY_ID>/final_report_vN.json
   INSURANCE_POLICY_SCRUTINY_AGENT/output/reports/<COMPANY_ID>/<POLICY_ID>/final_report_vN.md
   ```
8. Present for HITL (if required) and persist final verdict to memory only after Confirm.

## Rules & Constraints
- Do not change comparison artifacts; reports are derived-only.
- Final Pass/Fail determination must be auditable: include counts, thresholds, and the exact rule that produced the verdict.
- Redact sensitive PII in human-readable outputs unless configured to display.
- All report writes must create an entry in audit.log with provenance.

## Quick Reference
| Operation | Function | Output |
|---|---:|---|
| Generate report | report_generator.generate(inputs, config) | final_report.json, final_report.md |
| Save PDF | report_generator.render_pdf(markdown) | final_report_vN.pdf |
| Present for Confirm | HITL.present_for_confirm(brief, actions) | user Confirm |
