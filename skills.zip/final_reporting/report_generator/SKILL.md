---
name: report-generator
description: "Interface for generating final reports (structured JSON, markdown, PDF) from comparison artifacts."
license: Proprietary
---

# Report Generator (interface)

## Overview
The report_generator produces standardized final reports from compliance matrices and drift reports. It supports structured JSON outputs for downstream systems and markdown/PDF rendering for human review.

## When To Use
- When a final compliance_matrix.json and drift_report.json are available and a human-ready report is required.

## Step by Step Process
1. Input contract
   - Inputs: compliance_matrix, drift_report, mapping_table, optional metadata (company_id, policy_id, case_id), config (templates, thresholds).
2. Build report sections
   - Executive summary (TL;DR), Final Pass/Fail, Deviation Summary, Risk Report, Clause-level Findings, Evidence appendix, Actionable recommendations.
3. Render formats
   - Structured JSON (machine), Markdown (human), optional PDF (rendered from markdown). Attach provenance and timestamps.
4. Save outputs
   - Writing paths examples:
   ```
   INSURANCE_POLICY_SCRUTINY_AGENT/output/reports/<COMPANY_ID>/<POLICY_ID>/final_report_vN.json
   INSURANCE_POLICY_SCRUTINY_AGENT/output/reports/<COMPANY_ID>/<POLICY_ID>/final_report_vN.md
   ```
5. Return
   - Return report metadata: {report_path, summary, pass_fail, artifacts_linked}

## Rules & Constraints
- Maintain exact traceability: each finding must reference source file, page, and span if available.
- Do not include raw PII in markdown/PDF unless settings permit.
- Use company templates when present; fallback to default templates in skills/templates/.

## Quick Reference
| Function | Signature | Output |
|---|---:|---|
| generate | generate(compliance_matrix, drift_report, mapping_table, meta) | paths + metadata |
| render_markdown | render_markdown(structured_report) | markdown string |
| render_pdf | render_pdf(markdown, options) | PDF path |


