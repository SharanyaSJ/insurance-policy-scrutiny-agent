---
name: hitl
description: "Defines strict HITL workflow for any write to memory, case creation, or file storage."
license: Proprietary
---

# Human-In-The-Loop (HITL) Skill — Enforcement

## Overview
Defines strict HITL workflow for any write to memory, case creation, or file storage.

## When To Use
- Before any candidate write to storage or memory
- 

## Step by Step Process
1. title: "Human-In-The-Loop (HITL) Skill — Enforcement"
summary: "Defines strict HITL workflow for any write to memory, case creation, or file storage."
read_when:
  - Before any candidate write to storage or memory
---

2. # HITL Skill — Enforcement for Memory & Storage

3. Purpose
- Enforce human review and explicit confirmation for any action that writes files, updates memory, or creates/updates cases.
- Provide standardized presentation, confirmation parsing (full/partial), and audit recording.

4. Core rules (must always be followed)
1. Present candidate actions as a numbered plan exactly in the required format:

5. ```
I will: 1) save PDF to <path> 2) write extraction to <path> 3) add memory entry to <path>
Confirm?
```

6. 2. Do not perform any write until user replies with explicit "Confirm" or partial confirmations (e.g., "Confirm 1 and 3").
3. If user confirms partially, perform only the confirmed steps and present a new plan for remaining steps.
4. Record the human decision in audit.log with: {decision_text, by, timestamp, confirmed_steps, original_plan, session_id}.
5. All automatic candidate memory updates proposed by other skills must be routed through HITL Skill for confirmation unless the user has previously enabled auto_update for that specific bucket — in which case only write actions above the configured confidence thresholds are allowed.

7. Presentation requirements
- The brief to the human must include:
  - TL;DR (1–2 sentences)
  - Top N findings with confidence and page refs (bulleted)
  - Critical flags (contradictions, hidden clauses) with evidence snippets
  - The exact action plan (numbered) — must include file paths for each write
- When presenting evidence snippets, include page and line-range and avoid exposing PII unless user allowed PII in settings.

8. Confirmation parsing
- Accept exact keyword "Confirm" (case-insensitive) to proceed with all steps.
- Accept partial confirmations as "Confirm 1" or "Confirm 1 and 3" — parse integers and validate.
- For any step that initiates a financial transaction (payment, refund, charge), require an explicit payment confirmation. Accept either:
  - the exact phrase "Confirm Payment" (case-insensitive) to authorize all payment steps, or
  - a numbered payment confirmation such as "Confirm 3" or "Confirm Payment 3" to authorize a specific payment step.
- For high-value payments (amounts above a configurable threshold in company config), require an additional one-time token or multi-factor acknowledgment in the same reply (e.g. "Confirm Payment 3 — OTP 123456"). The exact threshold and MFA mechanism are configured per company in memory/companies/<COMPANY_ID>/config/payment_policy.json.
- If the reply is ambiguous, ask a single clarifying question that references the numbered plan (e.g., "Do you mean Confirm 1 and 3 or Confirm 1 only?").

9. Audit & traceability
- Append human decision to audit.log in the relevant folder. Example entry:
  {
    "decision_text": "Confirm 1 and 3",
    "by": "rahul.v",
    "timestamp": "2026-03-20T11:00:00Z",
    "confirmed_steps": [1,3],
    "original_plan": "I will: 1) ... 2) ... 3) ...",
    "session_id": "..."
  }
- After performing confirmed steps, append a second audit entry detailing actions taken with file paths and resulting checksums/version ids.

10. Error handling
- If any write fails, immediately log the failure and notify the user with a short TL;DR and the failed steps. Provide retry options.

11. Developer notes
- HITL Skill should be loaded by other skills (pdf_rfp, memory, etc.) before attempting writes.
- Keep confirmation parsing deterministic and strict.


## Rules & Constraints
> Core rules (must always be followed)
> 1. Present candidate actions as a numbered plan exactly in the required format:
> 
> ```
> I will: 1) save PDF to <path> 2) write extraction to <path> 3) add memory entry to <path>
> Confirm?
> ```
> 
> 2. Do not perform any write until user replies with explicit "Confirm" or partial confirmations (e.g., "Confirm 1 and 3").
> 3. If user confirms partially, perform only the confirmed steps and present a new plan for remaining steps.
> 4. Record the human decision in audit.log with: {decision_text, by, timestamp, confirmed_steps, original_plan, session_id}.
> 5. All automatic candidate memory updates proposed by other skills must be routed through HITL Skill for confirmation unless the user has previously enabled auto_update for that specific bucket — in which case only write actions above the configured confidence thresholds are allowed.
> 
> Presentation requirements
> - The brief to the human must include:
>   - TL;DR (1–2 sentences)
>   - Top N findings with confidence and pag

