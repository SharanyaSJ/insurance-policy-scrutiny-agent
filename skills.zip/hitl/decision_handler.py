"""
Decision handler for HITL responses: writes decision JSON for quote sheets and appends an audit log entry.

Usage:
  from decision_handler import handle_decision
  handle_decision(reply_text, metadata, action_plan, by, session_id)

When called, this will:
 - parse the user's reply for Approved/Rejected and feedback
 - write a decision JSON to output/pending_quotes/<COMPANY_ID>/<QUOTE_ID>_decision.json
 - append a compact audit JSON line to output/pending_quotes/<COMPANY_ID>/audit.log

This is a synchronous file-based stub intended for local testing; integrate with your memory/audit system as needed.
"""
import os
import json
import re
from datetime import datetime
from typing import Dict, Any, List, Optional

# Helpers
APPROVE_KEYWORDS = [r"\bapprove\b", r"\bapproved\b", r"\bapproved quote sheet\b"]
REJECT_KEYWORDS = [r"\breject\b", r"\brejected\b", r"\brejected quote sheet\b"]

def _match_any(patterns: List[str], text: str) -> bool:
    t = text.lower()
    for p in patterns:
        if re.search(p, t):
            return True
    return False


def parse_feedback(text: str) -> Optional[str]:
    """Extract trailing feedback after common separators like 'Feedback:', '-' or '\n'."""
    # Look for explicit 'feedback' label
    m = re.search(r"feedback\s*[:\-]\s*(.+)$", text, flags=re.IGNORECASE | re.DOTALL)
    if m:
        return m.group(1).strip()
    # If contains a newline, consider text after the first line as feedback
    if "\n" in text:
        parts = text.split("\n", 1)
        if len(parts) > 1 and parts[1].strip():
            return parts[1].strip()
    # If reply contains a dash separator
    if " - " in text:
        parts = text.split(" - ", 1)
        if len(parts) > 1:
            return parts[1].strip()
    # otherwise no feedback
    return None


def parse_confirmed_steps(text: str) -> List[int]:
    """Parse patterns like 'Confirm 1 and 3' or 'Confirm 1,2,3' and return list of ints."""
    nums = re.findall(r"\b(\d+)\b", text)
    return [int(n) for n in nums]


def build_paths(metadata: Dict[str, Any]) -> Dict[str, str]:
    company = metadata.get('company_id') or 'UNKNOWN_COMPANY'
    quote = metadata.get('quote_id') or 'UNKNOWN_QUOTE'
    base = f"INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_quotes/{company}"
    os.makedirs(base, exist_ok=True)
    decision_path = os.path.join(base, f"{quote}_decision.json")
    audit_log = os.path.join(base, "audit.log")
    return {"decision_path": decision_path, "audit_log": audit_log}


def handle_decision(reply_text: str, metadata: Dict[str, Any], action_plan: List[str], by: str, session_id: str) -> Dict[str, Any]:
    """Parse the reply and persist decision + audit.

    Returns the decision dict that was written.
    """
    text = (reply_text or '').strip()
    decision = None

    if _match_any(APPROVE_KEYWORDS, text):
        decision = 'Approved'
    elif _match_any(REJECT_KEYWORDS, text):
        decision = 'Rejected'
    else:
        # Also accept short phrases: 'approve' / 'reject'
        if re.search(r"\bapprove(d)?\b", text, flags=re.IGNORECASE):
            decision = 'Approved'
        elif re.search(r"\breject(ed)?\b", text, flags=re.IGNORECASE):
            decision = 'Rejected'

    feedback = parse_feedback(text) or 'Feedback captured'
    confirmed_steps = parse_confirmed_steps(text)

    # Payment authorization detection
    payment_authorized = False
    if re.search(r"confirm payment", text, flags=re.IGNORECASE):
        payment_authorized = True
    else:
        # if a numeric step corresponds to a payment step in the action_plan, detect it
        try:
            for n in confirmed_steps:
                idx = n - 1
                if 0 <= idx < len(action_plan):
                    if 'payment' in action_plan[idx].lower() or 'authorize' in action_plan[idx].lower():
                        payment_authorized = True
        except Exception:
            payment_authorized = False

    # Build decision record
    paths = build_paths(metadata)
    now = datetime.utcnow().isoformat() + 'Z'
    decision_record = {
        'quote_id': metadata.get('quote_id'),
        'company_id': metadata.get('company_id'),
        'decision': decision or 'Unknown',
        'feedback': feedback,
        'by': by,
        'timestamp': now,
        'confirmed_steps': confirmed_steps,
        'payment_authorized': payment_authorized,
        'session_id': session_id
    }

    # Write decision JSON
    try:
        with open(paths['decision_path'], 'w', encoding='utf-8') as f:
            json.dump(decision_record, f, indent=2)
    except Exception as e:
        raise RuntimeError(f"Failed to write decision file: {e}")

    # Append audit log (one JSON line)
    audit_entry = {
        'type': 'hitl_decision',
        'quote_id': decision_record['quote_id'],
        'company_id': decision_record['company_id'],
        'decision': decision_record['decision'],
        'feedback': decision_record['feedback'],
        'by': by,
        'timestamp': now,
        'confirmed_steps': confirmed_steps,
        'payment_authorized': payment_authorized,
        'session_id': session_id,
        'original_plan': action_plan
    }
    try:
        with open(paths['audit_log'], 'a', encoding='utf-8') as a:
            a.write(json.dumps(audit_entry) + "\n")
    except Exception as e:
        raise RuntimeError(f"Failed to append audit log: {e}")

    return decision_record


if __name__ == '__main__':
    # demo
    demo_metadata = {'company_id':'COMP-1234','quote_id':'QUOTE-20260320-aaaa'}
    demo_plan = [
        "Write staged extraction to INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_quotes/COMP-1234/QUOTE-20260320-aaaa_extraction_vA.json",
        "Present brief to human for HITL Confirm",
        "Authorize payment of 12000 USD to insurer (requires explicit 'Confirm Payment')"
    ]
    # Example replies to try:
    examples = [
        "Approved\nFeedback: Looks good to me.",
        "Rejected - coverage limits too low; Feedback: see comments",
        "Confirm 1 and 2",
        "Confirm 1,2 and 3",
        "Confirm Payment 3 - OTP 123456"
    ]
    for ex in examples:
        out = handle_decision(ex, demo_metadata, demo_plan, by='rahul.v', session_id='demo-session-1')
        print('Wrote:', out)
