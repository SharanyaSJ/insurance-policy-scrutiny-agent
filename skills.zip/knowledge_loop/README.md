Policy Scrutiny Knowledge Loop — README

Purpose
- Capture KB entries for policy scrutiny cases and actively use them as precedents in future cases.

Quick start
1) Write a candidate KB JSON that matches memory/schemas/knowledge_base_entry.schema.json
2) Run learning_updater.process_and_write(candidate, project_root, schema_path, auto_update=False).
   - If auto_update is False, you will receive a confirm_write response with the candidate and prelude stats for HITL.
   - If auto_update is True, the KB entry will be written immediately.
3) Retrieve precedents with kb_retriever.query({'tags':[...], 'text':'...'}, project_root)

Default paths (relative to skill folder):
- Schema: ../memory/schemas/knowledge_base_entry.schema.json
- Project root (default): two folders up from this file (project userfiles root)

Configurable thresholds (learning_updater.CONFIG)
- confidence_trigger: when agent confidence < trigger, KB retrieval is mandatory
- precedent_N: number of precedents required to consider precedent support
- cost_impact_threshold: numeric threshold for acceptability
- auto_update: default false (HITL required)

Grounding requirement
- Agent orchestration should call kb_retriever before making decisions and include at least one KB citation (file path + excerpt) in final recommendations.
- The retriever now returns a `citation_tag` field for each result. The orchestration MUST include the `citation_tag` string verbatim in agent outputs to preserve exact file-path formatting for downstream consumers and auditors. The citation_tag is formatted as:
  <file><file_path>FULL_PATH</file_path>FILENAME</file>


