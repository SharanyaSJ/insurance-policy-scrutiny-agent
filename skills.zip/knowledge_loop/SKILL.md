---
name: knowledge_loop
description: "Policy Scrutiny Knowledge Base & Learning Loop — learning_updater and kb_retriever"
license: Proprietary
---

# Knowledge Loop Skill — Policy Scrutiny Knowledge Base

## Overview

This skill provides the learning_updater and kb_retriever helpers for storing, indexing, and retrieving Policy Scrutiny knowledge base entries. The goal is to capture RFP baselines, quote & policy deviations, human decisions, and outcomes for every case (successful or not), then actively use those records in future cases.

## When to use
- After a case decision (HITL or automatic) to persist a KB entry
- When starting a new case, or when the agent is uncertain/stuck, to retrieve precedents and evidence
- When building aggregated evidence (dashboards, audits)

## Files & locations
- Schema: memory/schemas/knowledge_base_entry.schema.json
  <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/memory/schemas/knowledge_base_entry.schema.json</file_path>knowledge_base_entry.schema.json</file>
- Skills/helpers:
  - knowledge_loop/learning_updater.py
    <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/knowledge_loop/learning_updater.py</file_path>learning_updater.py</file>
  - knowledge_loop/kb_retriever.py
    <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/knowledge_loop/kb_retriever.py</file_path>kb_retriever.py</file>
  - knowledge_loop/README.md
    <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/knowledge_loop/README.md</file_path>README.md</file>

## Integration
- Uses the project memory storage convention described in:
  <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/memory/SKILL.md</file_path>memory/SKILL.md</file>

## Quick reference
- learning_updater.validate_and_write(candidate_json, auto_update=False)
- kb_retriever.query(context_dict, top_k=5)

Rules:
- All KB entries must validate against knowledge_base_entry.schema.json before writing
- KB writes are immutable _vN JSON files and have a sibling audit.log entry
- Retrieval responses include a file path citation and a short excerpt to ensure grounding
- Retrieval responses now include a stable citation tag field named `citation_tag` formatted as:
  <file><file_path>FULL_PATH</file_path>FILENAME</file>
  The agent orchestration MUST insert the string in `citation_tag` verbatim into the generated message so outputs are consistently formatted and easily audited.

