"""
kb_retriever.py

Lightweight retriever for Policy Scrutiny KB. Uses tag-boosted exact matches plus simple full-text search over stored KB JSON files.

Functions:
- query(context, project_root, top_k=5)

Returns:
- results: list of {kb_id, file, score, excerpt, outcome, tags}
- aggregate: counts and basic stats for matched set
"""

import os
import json
from glob import glob
import datetime

DEFAULT_PROJECT_ROOT = os.path.join(os.path.dirname(__file__), '..', '..')


def _score_match(doc, context):
    # simple heuristic: tag overlap + text overlap + recency
    score = 0.0
    tags = set(doc.get('tags', []))
    qtags = set(context.get('tags', []))
    tag_overlap = len(tags & qtags)
    score += tag_overlap * 2.0

    text_fields = ['observed_deviation', 'reasoning_summary', 'human_decision']
    qtext = context.get('text','').lower()
    text_score = 0
    for f in text_fields:
        v = doc.get(f)
        if isinstance(v, dict):
            v = json.dumps(v)
        if not v:
            continue
        vlower = str(v).lower()
        if qtext and qtext in vlower:
            text_score += 1
    score += text_score * 1.0

    # recency boost
    ts = doc.get('timestamp')
    if ts:
        try:
            dt = datetime.datetime.fromisoformat(ts.replace('Z',''))
            age_days = (datetime.datetime.utcnow() - dt).days
            recency = max(0, 365 - age_days) / 365.0
            score += recency * 0.5
        except Exception:
            pass
    return score


def _excerpt(doc, qtext):
    # return short excerpt from observed_deviation or reasoning_summary
    fields = ['observed_deviation', 'reasoning_summary']
    for f in fields:
        v = doc.get(f)
        if v:
            s = str(v)
            if qtext:
                idx = s.lower().find(qtext.lower())
                if idx >= 0:
                    start = max(0, idx-40)
                    return s[start: start+160].replace('\n',' ') + '...'
            return s[:160].replace('\n',' ') + '...'
    return ''


def query(context, project_root=None, top_k=5):
    if project_root is None:
        project_root = DEFAULT_PROJECT_ROOT
    search_root = os.path.join(project_root, 'memory')
    pattern = os.path.join(search_root, '**', 'kb', '*.json')
    files = glob(pattern, recursive=True)
    qtags = context.get('tags', [])
    qtext = context.get('text','')
    results = []
    for fp in files:
        try:
            with open(fp, 'r') as f:
                doc = json.load(f)
        except Exception:
            continue
        # fast filter: if qtags provided, require at least 1 overlap
        if qtags:
            if not set(qtags) & set(doc.get('tags', [])):
                continue
        score = _score_match(doc, {'tags': qtags, 'text': qtext})
        if score <= 0:
            continue
        kb_id = doc.get('kb_id')
        excerpt = _excerpt(doc, qtext)
        # ensure excerpt fallback
        if not excerpt:
            excerpt = (str(doc.get('observed_deviation') or doc.get('reasoning_summary') or '')[:160]).replace('\n',' ') + '...'
        # create stable citation tag required by orchestration
        file_name = os.path.basename(fp)
        citation_tag = f"<file><file_path>{fp}</file_path>{file_name}</file>"
        results.append({'kb_id': kb_id, 'file': fp, 'citation_tag': citation_tag, 'score': score, 'excerpt': excerpt, 'outcome': doc.get('outcome'), 'tags': doc.get('tags', [])})

    results = sorted(results, key=lambda r: r['score'], reverse=True)[:top_k]

    # aggregate
    agg = {'matched': len(results), 'by_outcome': {}}
    for r in results:
        agg['by_outcome'].setdefault(r['outcome'], 0)
        agg['by_outcome'][r['outcome']] += 1
    return {'results': results, 'aggregate': agg}


# CLI test
if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--project-root', default=os.path.join(os.path.dirname(__file__), '..', '..'))
    p.add_argument('--tags', nargs='*', default=[])
    p.add_argument('--text', default='')
    p.add_argument('--top', type=int, default=5)
    args = p.parse_args()
    out = query({'tags': args.tags, 'text': args.text}, project_root=args.project_root, top_k=args.top)
    print(json.dumps(out, indent=2))
