"""
learning_updater.py

Simple helper to validate and persist knowledge base entries for the Policy Scrutiny KB.

Functions:
- validate_candidate(candidate, schema_path)
- enrich_candidate(candidate)
- find_precedents(candidate, search_root)
- write_kb_entry(candidate, base_path, auto_update=False)

This is intentionally lightweight and file-based so it can be reviewed and extended.
"""

import json
import os
import uuid
import datetime
from jsonschema import validate, ValidationError
from glob import glob

# Configurable defaults
CONFIG = {
    "confidence_trigger": 0.9,
    "precedent_N": 2,
    "cost_impact_threshold": 10000,
    "auto_update": False,
    "schema_version": "v1",
    "processor_version": "learning_updater_v1"
}


def load_schema(schema_path):
    with open(schema_path, 'r') as f:
        return json.load(f)


def validate_candidate(candidate, schema_path):
    schema = load_schema(schema_path)
    try:
        validate(instance=candidate, schema=schema)
        return True, None
    except ValidationError as e:
        return False, str(e)


def ensure_tags(candidate):
    tags = set(candidate.get('tags', []))
    for k in ('insurer', 'clause_type', 'deviation_type', 'outcome'):
        v = candidate.get(k)
        if v:
            tags.add(str(v))
    candidate['tags'] = list(tags)
    return candidate


def find_precedents(candidate, search_root):
    """
    Scan existing KB JSON files under search_root (e.g., project memory path) and compute a simple precedent score.
    Scoring heuristic (simple): match_count / total_considered * accepted_ratio
    """
    tags = set(candidate.get('tags', []))
    pattern = os.path.join(search_root, '**', 'kb', '*.json')
    files = glob(pattern, recursive=True)
    matched = []
    accepted = 0
    total = 0
    now = datetime.datetime.utcnow()
    for fp in files:
        try:
            with open(fp, 'r') as f:
                doc = json.load(f)
        except Exception:
            continue
        total += 1
        doc_tags = set(doc.get('tags', []))
        # tag overlap
        overlap = len(tags & doc_tags)
        if overlap == 0:
            continue
        matched.append((fp, doc, overlap))
        if doc.get('outcome') in ('accepted', 'conditional_accept'):
            accepted += 1
    precedent_score = 0.0
    if total > 0 and len(matched) > 0:
        precedent_score = (len(matched) / total) * (accepted / len(matched) if len(matched)>0 else 0)
    matches = [fp for fp,_,_ in matched[:10]]
    # create tagged citations for matches to ensure downstream formatting
    matches_tagged = []
    for fp in matches:
        fname = os.path.basename(fp)
        tag = f"<file><file_path>{fp}</file_path>{fname}</file>"
        matches_tagged.append(tag)
    stats = {
        'matched_count': len(matched),
        'total_considered': total,
        'accepted_count': accepted,
        'precedent_score': precedent_score,
        'matches': matches,
        'matches_tagged': matches_tagged
    }
    return stats


def make_kb_id():
    now = datetime.datetime.utcnow().strftime('%Y%m%d')
    suffix = uuid.uuid4().hex[:6].upper()
    return f"KB-{now}-{suffix}"


def write_kb_entry(candidate, project_root, auto_update=None):
    """
    Write candidate to memory/cases/<case_id>/kb/KB-..._vN.json (or memory/global/...) and create audit.log
    Returns file path on success.
    """
    if auto_update is None:
        auto_update = CONFIG['auto_update']

    case_id = candidate.get('case_id')
    if case_id:
        kb_dir = os.path.join(project_root, 'memory', 'cases', case_id, 'kb')
    else:
        # global bucket
        kb_dir = os.path.join(project_root, 'memory', 'global')
    os.makedirs(kb_dir, exist_ok=True)

    # id & versioning
    kb_id = candidate.get('kb_id') or make_kb_id()
    candidate['kb_id'] = kb_id
    candidate.setdefault('schema_version', CONFIG['schema_version'])
    candidate.setdefault('processor_version', CONFIG['processor_version'])
    candidate.setdefault('timestamp', datetime.datetime.utcnow().isoformat() + 'Z')

    # Determine next version
    base_fp = os.path.join(kb_dir, f"{kb_id}")
    v = 1
    while True:
        fp = f"{base_fp}_v{v}.json"
        if not os.path.exists(fp):
            break
        v += 1
    # write
    with open(fp, 'w') as f:
        json.dump(candidate, f, indent=2, sort_keys=True)

    # audit
    audit = {
        'action': 'write_kb_entry',
        'file': fp,
        'timestamp': datetime.datetime.utcnow().isoformat() + 'Z',
        'by': 'learning_updater',
        'schema_version': candidate.get('schema_version'),
    }
    audit_fp = os.path.join(kb_dir, 'audit.log')
    with open(audit_fp, 'a') as af:
        af.write(json.dumps(audit) + "\n")

    return fp


# Example high-level function combining steps
def process_and_write(candidate, project_root, schema_path, auto_update=None):
    # Ensure required id/timestamps before validation so the schema can require them
    candidate.setdefault('kb_id', make_kb_id())
    candidate.setdefault('schema_version', CONFIG['schema_version'])
    candidate.setdefault('processor_version', CONFIG['processor_version'])
    candidate.setdefault('timestamp', datetime.datetime.utcnow().isoformat() + 'Z')

    # validate
    valid, err = validate_candidate(candidate, schema_path)
    if not valid:
        return {'ok': False, 'error': 'schema_validation_failed', 'details': err}

    # ensure tags
    candidate = ensure_tags(candidate)

    # compute precedents
    stats = find_precedents(candidate, os.path.join(project_root, 'memory'))
    candidate['precedent_score'] = stats.get('precedent_score', 0.0)
    # include citations lists for downstream grounding (raw paths + tagged)
    candidate['citations'] = stats.get('matches', [])
    candidate['citations_tagged'] = stats.get('matches_tagged', [])

    # decide acceptability simple rules (config-driven)
    acceptability = {
        'cost_ok': (candidate.get('cost_impact') is None) or (candidate.get('cost_impact', 0) <= CONFIG['cost_impact_threshold']),
        'precedent_ok': stats.get('matched_count', 0) >= CONFIG['precedent_N'] and stats.get('accepted_count', 0) > 0,
    }
    candidate['acceptability'] = acceptability

    # If auto_update False: return candidate for HITL confirmation
    if auto_update is None:
        auto_update = CONFIG['auto_update']
    if not auto_update:
        # package for HITL
        return {'ok': True, 'action': 'confirm_write', 'candidate': candidate, 'prelude': stats}

    # write
    fp = write_kb_entry(candidate, project_root, auto_update=auto_update)
    return {'ok': True, 'action': 'wrote', 'file': fp, 'prelude': stats}


# CLI-style test helper
if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--project-root', default=os.path.join(os.path.dirname(__file__), '..', '..'))
    p.add_argument('--schema', default=os.path.join(os.path.dirname(__file__), '..', 'memory', 'schemas', 'knowledge_base_entry.schema.json'))
    p.add_argument('--input-json')
    p.add_argument('--auto', action='store_true')
    args = p.parse_args()
    if not args.input_json:
        print('Provide --input-json path')
        raise SystemExit(1)
    with open(args.input_json, 'r') as f:
        candidate = json.load(f)
    out = process_and_write(candidate, args.project_root, args.schema, auto_update=args.auto)
    print(json.dumps(out, indent=2))
