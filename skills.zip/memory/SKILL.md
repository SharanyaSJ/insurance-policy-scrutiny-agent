---
name: memory
description: "Rules and concrete schemas for project memory: global, company, case. Includes JSON Schema references and examples to make memory writes deterministic and auditable."
license: Proprietary
---

# Memory Skill — Insurance Policy Scrutiny Agent (Concrete)

## Overview
Defines when and how the agent stores structured records in three buckets (global, company, case). This version includes explicit JSON Schemas and example payloads so other skills can validate candidate memory writes automatically.

## Schemas (locations)
- ingest_metadata.schema.json — metadata for ingestion events and RFP/policy/quote artifacts
  <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/memory/schemas/ingest_metadata.schema.json</file_path>ingest_metadata.schema.json</file>
- mapping_table.schema.json — canonical mapping table rows for multi-source mapping
  <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/memory/schemas/mapping_table.schema.json</file_path>mapping_table.schema.json</file>
- compliance_matrix.schema.json — final compliance matrix rows and summary
  <file><file_path>/root/kogo-data/user/69b2291113b3fe7a44afb2bb/69bcdaf255cd8ceb8440a491/userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/skills/memory/schemas/compliance_matrix.schema.json</file_path>compliance_matrix.schema.json</file>

## When to use
- When a skill (pdf_rfp, quote_sheet, policy_document_ingestion, three_way_comparison, final_reporting) proposes a durable memory write.
- Candidate writes must be validated against an appropriate schema before being presented to HITL.

## Concrete process
1) Skill prepares candidate memory JSON and selects schema (e.g., ingest_metadata.schema.json)
2) Validate candidate against schema locally; if validation fails, produce a structured error and do NOT present to HITL as a write candidate (instead create a remediation brief)
3) If validation passes and auto_update for the bucket is OFF, package a HITL action plan and present for Confirm. On Confirm, write immutable _vN record and append audit entry.

## Example: ingest metadata (ingest_metadata.schema.json)
- Example instance:
{
  "ingest_id": "ING-20260320-0001",
  "company_id": "COMP-123",
  "artifact": "rfp",
  "artifact_path": "data/companies/COMP-123/rfps/RFP-2026-0001_v1.pdf",
  "extraction_path": "memory/companies/COMP-123/rfps/RFP-2026-0001_v1.json",
  "confidence": 0.87,
  "processor_version": "v1.2.0",
  "timestamp": "2026-03-20T11:10:00Z"
}

## Memory naming & storage rules (concrete)
- All records are JSON and must include a schema_version field matching the included schema file.
- File paths:
  - Global: memory/global/<YYYYMMDD>_<slug>_<id>.json
  - Company: memory/companies/<COMPANY_ID>/<record_type>/<id>_vN.json
  - Case: memory/cases/<CASE_ID>/record_vN.json and decisions/<DECISION_ID>.json
- Audit: each write has a sibling audit.log entry with {action, file, timestamp, by, confidence, schema_version}

## Failure modes (memory)
- Schema validation error: do not write; present remediation with specific field errors
- Permission error: log and surface to user; require elevated permissions
- Duplicate id/version collision: increment versioning or create new id; never overwrite existing _vN
- Disk/full/IO error: retry with backoff and escalate to operator if persistent

## Upstream / Downstream
- Upstream: ingestion pipelines (pdf_rfp, quote_sheet, policy_document_ingestion), HITL (decisions)
- Downstream: three_way_comparison, final_reporting, dashboards, audit reviewers

## Developer notes
- Include schema_version in every record and keep schemas under skills/memory/schemas for discoverability.
- Provide helper utilities: memory/validate.py to validate instances against schemas before HITL presentation.

