---
name: memory
description: "Rules and automation for reading, classifying, and writing three types of memory: global, company, case."
license: Proprietary
---

# Memory Skill — Insurance Policy Scrutiny Agent

## Overview
Rules and automation for reading, classifying, and writing three types of memory: global, company, case.

## When To Use
- When the agent ingests documents, RFPs, policies, or user conversations
- When the agent considers writing or updating memory
- 

## Step by Step Process
1. title: "Memory Skill — Insurance Policy Scrutiny Agent"
summary: "Rules and automation for reading, classifying, and writing three types of memory: global, company, case."
read_when:
  - When the agent ingests documents, RFPs, policies, or user conversations
  - When the agent considers writing or updating memory
---

2. # Memory Skill — Insurance Policy Scrutiny Agent

3. Purpose
- Define when and how the agent stores knowledge in three memory buckets: Global, Company, Case.
- Provide clear update triggers, file formats, naming conventions, and safety controls (consent & audit).

4. Memory types
1. Global
  - Contents: standard clauses, domain definitions, common clause patterns, canonical term definitions, heuristics and rule-of-thumb snippets derived from multiple companies.
  - Location: INSURANCE_POLICY_SCRUTINY_AGENT/memory/global/
  - Files: JSON records and a single index (global_index.json).
  - Trigger to update: when the agent reads multiple documents (>=2) or a high-confidence pattern (confidence >= 0.9) appears across documents, mark as candidate. If auto_update enabled, append to global store; otherwise present plan and ask Confirm.

5. 2. Company
  - Contents: company-specific RFPs, risk tolerance statements, past decisions, policy templates specific to that company, negotiation notes and local conventions.
  - Location: INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/<COMPANY_ID>/
  - Files: metadata.json, rfp_records/, decisions.json, index.json
  - Trigger to update: when an RFP or upload is associated with a company (explicit or inferred) and the content contains company-specific preferences or decisions. If auto_update enabled for company, agent will write; otherwise show action plan and ask Confirm.

6. 3. Case
  - Contents: one record per insurance renewal or case. Stores human decisions, final outcome, timestamps, comparison of RFP vs Quote vs Policy, notes and rationale.
  - Location: INSURANCE_POLICY_SCRUTINY_AGENT/memory/cases/<CASE_ID>/
  - Files: record.json (immutable historical versions with _v1/_v2), audit.log
  - Trigger to update: when a case is created or closed, or when an agent documents a decision. Agent should by default create a candidate case record and ask user to Confirm before saving unless explicit auto-save for cases is enabled.

7. Heuristics & confidence
- The agent must attach a confidence score [0.0-1.0] for any suggested memory write.
- Suggested thresholds (configurable):
  - Global updates: confidence >= 0.9 OR observed pattern across >= 3 distinct sources.
  - Company updates: confidence >= 0.75 OR explicit company reference in source.
  - Case records: any decision recorded by a human is saved with confidence 1.0; agent-suggested facts require confirmation.

8. File formats & examples
- Global record (JSON): id, title, summary, source_refs, clause_text, tags, confidence, created_at, created_by
- Company metadata (JSON): id, name, legal_name, contacts, schema_version, notes
- Case record (JSON): case_id, company_id, decision_summary, final_outcome, rfp_vs_quote_vs_policy_comparison, human_decision, timestamps, contributors

9. Safety & consent
- Default auto_update flag is OFF for all buckets unless the user explicitly enables it.
- The agent will always produce a numbered action plan when it intends to write to memory and will ask for Confirm unless auto_update was previously enabled by the user for that bucket.
- All writes must include audit metadata (who, when, source_document, confidence).

10. APIs / Agent behavior
- When reading a new document the agent should:
  1) Extract structured data (entities, clauses, definitions).
  2) Classify candidate memories: global/company/case with confidence scores.
  3) If auto_update enabled for that bucket and confidence >= threshold, write and log; otherwise present action plan to user and await Confirm.

11. Paths & naming conventions (always use these)
- Global: INSURANCE_POLICY_SCRUTINY_AGENT/memory/global/<YYYYMMDD>_<slug>_<id>.json
- Company: INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/<COMPANY_ID>/metadata.json
- Company RFPs: INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/<COMPANY_ID>/rfps/<RFP_ID>.json
- Cases: INSURANCE_POLICY_SCRUTINY_AGENT/memory/cases/<CASE_ID>/record_v1.json

12. Audit & versioning
- Every write must append an entry to audit.log in the same folder with: {action, file, timestamp, by, confidence, source}
- For updates, write a new _vN file and update an index pointing to the latest version.

13. Developer notes
- Do not hard-delete memory files; use tombstone entries for removals.
- Store PII flags at record-level; if PII present, mark record and follow storage/encryption policy (ask user for configuration).

14. Enablement
- To enable automatic behavior for a bucket, set INSURANCE_POLICY_SCRUTINY_AGENT/memory/settings.json {"auto_update_global":true|false, "auto_update_company": true|false, "auto_update_case": true|false}
- The agent must confirm when this settings file is created or changed.

15. Examples and templates are stored under the agent-memory README and templates folder.


## Rules & Constraints
- Preserve original logic and do not write to memory without confirmation when applicable.

## Quick Reference
| Operation | Path / Note |
|---|---:|
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/memory/global/` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/<COMPANY_ID>/` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/memory/cases/<CASE_ID>/` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/memory/global/<YYYYMMDD>_<slug>_<id>.json` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/<COMPANY_ID>/metadata.json` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/<COMPANY_ID>/rfps/<RFP_ID>.json` |