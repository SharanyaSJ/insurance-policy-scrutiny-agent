#!/usr/bin/env python3
"""
Memory writer helper for Insurance Policy Scrutiny Agent.
Provides simple append APIs for project-global, company-level and case-level memories.
"""
import os
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))  # skills/memory -> project root
MEMORY_DIR = os.path.join(ROOT, 'memory')


def _ensure(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)


def _timestamp():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def append_global(topic: str, text: str):
    path = os.path.join(MEMORY_DIR, 'GLOBAL_MEMORY.md')
    _ensure(path)
    with open(path, 'a', encoding='utf-8') as f:
        f.write(f"\n## [{_timestamp()}] {topic}\n{text}\n")
    return path


def append_company(company_id: str, topic: str, text: str):
    path = os.path.join(MEMORY_DIR, 'companies', company_id, 'MEMORY.md')
    _ensure(path)
    with open(path, 'a', encoding='utf-8') as f:
        f.write(f"\n## [{_timestamp()}] {topic}\n{text}\n")
    return path


def append_case(case_id: str, topic: str, text: str):
    path = os.path.join(MEMORY_DIR, 'cases', case_id, 'memory.md')
    _ensure(path)
    with open(path, 'a', encoding='utf-8') as f:
        f.write(f"\n## [{_timestamp()}] {topic}\n{text}\n")
    return path


def append_error(stage: str, case_id: str = None, company_id: str = None, error_message: str = None, traceback: str = None, artifacts: list = None, action: str = None, next_steps: str = None):
    """Write a structured incident JSON and append a brief to relevant memories.

    The incident is saved to memory/incidents/<YYYY-MM-DD>/incident_<timestamp>_<uuid>.json
    A short human-readable note is appended to GLOBAL_MEMORY.md and, if provided, to company and case memories.
    """
    import json
    import uuid

    ts = datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')
    incident = {
        'timestamp': ts,
        'stage': stage,
        'case_id': case_id,
        'company_id': company_id,
        'error_message': error_message,
        'traceback': (traceback or '')[:2000],
        'action': action,
        'artifacts': artifacts or [],
        'next_steps': next_steps
    }
    # ensure incidents dir
    incidents_dir = os.path.join(MEMORY_DIR, 'incidents', datetime.now().strftime('%Y-%m-%d'))
    os.makedirs(incidents_dir, exist_ok=True)
    fid = uuid.uuid4().hex[:8]
    fname = f"incident_{datetime.now().strftime('%H%M%S')}_{fid}.json"
    fpath = os.path.join(incidents_dir, fname)
    with open(fpath, 'w', encoding='utf-8') as fh:
        json.dump(incident, fh, indent=2, sort_keys=True)

    # append brief to global memory
    brief = f"Incident at stage={stage}; case={case_id}; company={company_id}; action={action}; next_steps={next_steps}; incident_file={fpath}"
    try:
        append_global(f"Incident: {stage}", brief)
    except Exception:
        pass

    # append to company and case memory if present
    try:
        if company_id:
            append_company(company_id, f"Incident: {stage}", brief)
    except Exception:
        pass
    try:
        if case_id:
            append_case(case_id, f"Incident: {stage}", brief)
    except Exception:
        pass

    return fpath


if __name__ == '__main__':
    # simple test when run directly
    append_global('test', 'Initialized memory writer test')
    append_company('NovaTech', 'test', 'Company memory test')
    append_case('RFP_NovaTech_1773999195', 'test', 'Case memory test')
    print('Memory test written to', MEMORY_DIR)
