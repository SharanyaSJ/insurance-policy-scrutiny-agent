---
name: pdf-rfp
description: "Reads RFP PDFs, extracts insurance-relevant details (explicit and implicit), detects contradictions and vague language, and prepares a human-review brief. Enforces HITL before saving to memory."
license: Proprietary
---

# PDF RFP Reading Skill — Insurance Policy Scrutiny Agent

## Overview
Reads RFP PDFs, extracts insurance-relevant details (explicit and implicit), detects contradictions and vague language, and prepares a human-review brief. Enforces HITL before saving to memory.

## When To Use
- When an RFP PDF is uploaded or ingested for a company
- When the agent proposes to store extraction results or update memory

## Upstream / Downstream
- Upstream: raw PDF upload, OCR engines, language-detection, company config (memory)
- Downstream: HITL (review/decision), memory (on Confirm), rfp_quote_compare (for comparisons), three_way_comparison (when policy available)

## Step by Step Process (summary)
1) Stage PDF and write manifest (checksum, uploader, metadata)
2) Preprocess (decompress, rotation, page split)
3) OCR & structural extraction (text, headings, tables, lists)
4) Clause/entity extraction and confidence scoring
5) Validate extraction against rfp_extraction_schema.json
6) Generate human brief and present for HITL Confirm
7) On Confirm: immutable writes (versioned), index updates, diff generation, optional memory writes via HITL

## Outputs
- Staging: output/pending_briefs/<RFP_ID>_brief.md, *_extraction.json
- Canonical (on Confirm): data/companies/<COMPANY_ID>/rfps/<RFP_ID>_vN.pdf and memory entries per memory rules

## Failure modes (detection & safe fallback)
- corrupt_pdf: detect via PDF parser errors → quarantine and notify uploader
- password_protected: do not brute force → quarantine with instructions
- ocr_failure: retry alternate OCR engines then quarantine with logs
- missing_required_fields: validation failure → quarantine and create action plan for human
- low_confidence_critical_items: present to HITL and mark REQUIRES_REVIEW; do not auto-write
- large_file_timeout: chunk-processing fallback or escalate to manual review
- duplicate_ingest: detect via checksum → link to existing version and increment reference counter
- persistence_failure: log, retry with exponential backoff, and present minimal failure brief to human

## QA & checks
- Validate extraction JSON against INSURANCE_POLICY_SCRUTINY_AGENT/data/templates/rfp_extraction_template.json
- Ensure manifest checksum matches stored file
- For quarantined items, include suggested remediation and retry policy in brief

## Memory interaction (concrete)
- Candidate memory writes are packaged as: { type: "company_rfp", company_id, rfp_id, version, fields[], confidence }
- Memory writes are routed through HITL unless auto_update for the target bucket is enabled. All memory records must conform to memory schemas: skills/memory/schemas/ingest_metadata.schema.json

## Examples
- See templates in data/templates/ for extraction and manifest formats.

