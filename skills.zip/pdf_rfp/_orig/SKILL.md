---
name: pdf-rfp
description: "Reads RFP PDFs, extracts insurance-relevant details (explicit and implicit), detects contradictions and vague language, and prepares a human-review brief. Enforces HITL before saving to memory."
license: Proprietary
---

# PDF RFP Reading Skill — Insurance Policy Scrutiny Agent

## Overview
Reads RFP PDFs, extracts insurance-relevant details (explicit and implicit), detects contradictions and vague language, and prepares a human-review brief. Enforces HITL before saving to memory.

## When To Use
- When an RFP PDF is uploaded or ingested for a company
- When the agent proposes to store extraction results or update memory
- 

## Step by Step Process
1. title: "PDF RFP Reading Skill — Insurance Policy Scrutiny Agent"
summary: "Reads RFP PDFs, extracts insurance-relevant details (explicit and implicit), detects contradictions and vague language, and prepares a human-review brief. Enforces HITL before saving to memory."
read_when:
  - When an RFP PDF is uploaded or ingested for a company
  - When the agent proposes to store extraction results or update memory
---

2. # PDF RFP Reading Skill (Hardened)

3. Purpose
- Fully parse an RFP (Request for Proposal) PDF and extract all insurance-relevant information — explicit and implicit — while providing robust error handling, immutable versioning, and edge-case coverage.
- Produce a concise human-review brief and a detailed machine-readable extraction with confidence scores per item.
- Enforce strict Human-In-The-Loop (HITL) review before any persistent memory write or case save.

4. Inputs
- PDF file (binary) and metadata: {company_id, uploader, uploaded_at, source_filename, suggested_case_id (optional), source_id (optional)}

5. Primary outputs (saved only after explicit human Confirm)
- Original PDF stored as:
  INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/<COMPANY_ID>/rfps/<RFP_ID>_vN.pdf
- Manifest: <RFP_ID>_vN.manifest.json (checksums, uploader, timestamps)
- Extraction JSON: <RFP_ID>_vN_extraction.json (structured fields + confidences)
- Brief (human-readable) saved to outputs pending briefs until human confirms save
- On Confirm: copy extraction into memory per memory rules:
  - INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/<COMPANY_ID>/rfps/<RFP_ID>_vN.json
  - INSURANCE_POLICY_SCRUTINY_AGENT/memory/cases/<CASE_ID>/record_vN.json (if case provided/created)
- All writes append to audit.log with metadata (actor, timestamp, source, confidence)

6. Rejection handling (quarantine and recovery)
- When an ingest fails verification, parsing, or produces low-confidence critical items, the RFP is quarantined rather than discarded.
- Quarantine folder:
  INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/<COMPANY_ID>/rfps/quarantine/<RFP_ID>_vN/
- Quarantine metadata includes: reason_code, human_readable_reason, attempted_steps, retry_count, last_error, suggestions_for_fix, original_manifest.
- Rejection reasons (examples): corrupt_pdf, password_protected, ocr_failure, unknown_encoding, extremely_low_confidence, missing_required_sections, parsing_error, file_too_large.
- Recovery options: automatic retry policy (configurable), manual review UI link, manual override to promote to staging, or request re-upload.
- All quarantine actions create audit.log entries and notify uploader (if contact info supplied) with suggested next steps.

7. Versioning & provenance
- All canonical saves are immutable and versioned. Naming pattern includes _vN where N increments on each confirmed write.
- Maintain index.json in each rfps/ folder mapping rfp_id -> latest_version and historical versions with checksums and timestamps.
- When a new extraction is produced that differs from a prior one, create a diff summary (changed fields, confidence deltas) and store as <RFP_ID>_vN_diff.json.
- Deduplication: if checksum matches an existing version, increment a reference counter and link to existing version rather than duplicate storage.

8. Edge-case coverage (robust parsing)
- Handle: scanned PDFs (OCR), rotated pages, multi-column layouts, tables and annexed schedules, small-font and footers, embedded files, password-protected files (detect and quarantine), digital signatures, non-English text (language detection + fallback), extremely large files (split processing), and malformed PDFs.
- Detection & fallback strategies:
  - If OCR fails: try an alternate OCR engine, then mark ocr_failure and quarantine after retries.
  - For rotated pages: auto-detect rotation and auto-rotate before OCR.
  - For tables: run table extraction heuristics and map rows to structured fields with row/column refs.
  - For multi-column layouts: use layout-aware OCR to preserve reading order.
  - For encrypted PDFs: do not attempt brute force; mark password_protected and quarantine with instructions.

9. Checks & validation
- Before proposing memory writes, validate extracted JSON against rfp_extraction_schema.json.
- Fail fast on missing required fields (company_id, rfp_id, at least one coverage limit) — these trigger quarantine with clear reason.
- Compute overall_confidence metric and flag if below warning threshold; include this in brief and quarantine if critical.

10. Process workflow (enhanced)
1) Receive PDF and metadata; write to staging with temporary id and manifest. Attempt checksum and basic validation.
2) Run pre-processing (decompression, rotation, page-splitting). If critical failure, quarantine and notify.
3) Run OCR (multi-engine retries) and full extraction with structural parsing.
4) Run contradiction detection, ambiguity heuristics, entity extraction, and compute per-field confidences.
5) Validate extraction against schema; if validation fails, quarantine with reasons.
6) Generate a brief (staging) that includes rejection flags, version info, diffs vs prior versions (if any), and the exact numbered action plan.
7) Present brief + action plan to human for Confirm. Agent must not write canonical files or memory until Confirm.
8) On Confirm: perform immutable writes (vN), update index.json, produce diffs, append audit logs, and optionally push candidate memory updates (routed through memory skill and HITL rules).

11. Presentation to human (HITL)
- The brief must include:
  1) TL;DR summary of main findings and overall_confidence.
  2) Key Facts (company, uploaded_at, uploader, primary coverage limits) with page refs and confidences.
  3) Rejection/warning indicators (if any) with concise human-readable reasons and suggested remediation.
  4) Version info and diffs vs prior saved versions (if present).
  5) Critical flags: contradictions, vague language, hidden clauses with evidence snippets.
  6) The action plan (numbered) exactly in the form required by response formatting rules — include quarantine actions if applicable:
     I will: 1) save PDF to X 2) write extraction to Y 3) add to memory Z
     Confirm?
- The agent must redact PII in briefs unless user settings allow PII display.

12. APIs & integration points
- expose operations (pseudo-API):
  - ingest_rfp(pdf_bytes, metadata) → candidate_brief, candidate_extraction, manifest or quarantine_notice
  - generate_brief(extraction) → brief_text
  - present_for_confirm(brief, actions) → await user Confirm
  - commit_on_confirm(confirm_payload) → immutable writes, index update, diffs, audit
  - quarantine_status(rfp_id) → status, reasons, retry options
  - retry_quarantine(rfp_id) → re-run processing (with backoff and attempt counters)

13. Templates and examples
- Use INSURANCE_POLICY_SCRUTINY_AGENT/data/templates/rfp_extraction_template.json for extraction format.
- Use INSURANCE_POLICY_SCRUTINY_AGENT/data/templates/rfp_manifest_template.json for manifest format.
- Provide edge-case checklist and example manifests in tests/ for validation.

14. Safety & audit
- All actions (quarantine, retries, confirms, writes) log to audit.log with a full record: {action, file, timestamp, by, session_id, reason, confidence, prior_version}
- Never auto-save to global memory without explicit setting and user confirmation.
- Keep a tombstone record for any removal action; never hard-delete without explicit multi-step approval.

15. Developer notes
- Implement rejection.py for quarantine & retry logic, versioning.py for write helpers, and update parser_stub and presenter to call these helpers.
- Add tests covering each edge case; include a test runner script in tests/run_tests.sh.

16. # Presenter module

17. Purpose
- Convert the detailed extraction JSON into a clear, concise human brief designed for quick review and HITL confirmation. The presenter builds both a markdown brief and a structured brief JSON that the UI or CLI can render.

18. Files
- INSURANCE_POLICY_SCRUTINY_AGENT/skills/pdf_rfp/presenter.py  (generation functions)
- INSURANCE_POLICY_SCRUTINY_AGENT/skills/pdf_rfp/brief_template.md (human-readable template)
- INSURANCE_POLICY_SCRUTINY_AGENT/skills/pdf_rfp/brief_schema.json (schema for structured brief)
- INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_briefs/ (staging location for briefs)

19. Presenter behavior
1) Accept extraction JSON and metadata, redact PII per settings, and compute an overall confidence summary.
2) Produce a short TL;DR (1–2 sentences) capturing the top-level recommendation or risk posture.
3) List Key Facts (company, uploaded_at, uploader, policy types requested, primary coverage limits) as bullets with page refs and confidences.
4) Enumerate Hidden/Implicit Clauses and Contradictions with brief evidence snippets.
5) Provide Recommended Actions and an exact numbered write plan (paths must be included in a code block). Include rejection/quarantine reasons if present.
6) Output both a markdown brief saved to INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_briefs/<RFP_ID>_brief.md and a structured JSON brief saved to the same folder.

20. Human review
- The brief is the canonical review artifact. The agent must present it and the numbered action plan and wait for HITL Confirm before any write. Partial confirms supported.


## Rules & Constraints
> Safety & audit
> - All actions (quarantine, retries, confirms, writes) log to audit.log with a full record: {action, file, timestamp, by, session_id, reason, confidence, prior_version}
> - Never auto-save to global memory without explicit setting and user confirmation.
> - Keep a tombstone record for any removal action; never hard-delete without explicit multi-step approval.
> 
> Developer notes
> - Implement rejection.py for quarantine & retry logic, versioning.py for write helpers, and update parser_stub and presenter to call these helpers.
> - Add tests covering each edge case; include a test runner script in tests/run_tests.sh.
> 
> # Presenter module
> 
> Purpose
> - Convert the detailed extraction JSON into a clear, concise human brief designed for quick review and HITL confirmation. The presenter builds both a markdown brief and a structured brief JSON that the UI or CLI can render.
> 
> Files
> - INSURANCE_POLICY_SCRUTINY_AGENT/skills/pdf_rfp/presenter.py  (generation functions)
> - INSURANCE_POLICY_SCRUTINY_AGENT/skills/pdf_rfp/brief_template.md (human-readable template)
> - INSURANCE_POLICY_SCRUTINY_AGENT/skills/pdf_rfp/brief_schema.json (schema for structured brief)
> - INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_briefs/ (staging location for briefs)

## Quick Reference
| Operation | Path / Note |
|---|---:|
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/<COMPANY_ID>/rfps/<RFP_ID>_vN.pdf` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/<COMPANY_ID>/rfps/<RFP_ID>_vN.json` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/memory/cases/<CASE_ID>/record_vN.json (if case provided/created)` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/<COMPANY_ID>/rfps/quarantine/<RFP_ID>_vN/` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/data/templates/rfp_extraction_template.json for extraction format.` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/data/templates/rfp_manifest_template.json for manifest format.` |