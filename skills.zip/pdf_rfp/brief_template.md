TL;DR: {{tldr}}

Details:
- Company: {{company_id}}
- Uploaded by: {{uploaded_by}} at {{uploaded_at}}
- Primary coverage limits:
{{#coverage_limits}}
- {{amount}} (p{{page}}, conf {{confidence}})
{{/coverage_limits}}

Hidden / Contradictions:
{{#flags}}
- {{.}}
{{/flags}}

Code / Paths:
```
{{#paths}}
{{.}}
{{/paths}}
```

Action: Provide explicit Confirm to perform the numbered steps above.
