"""
Presenter module for the PDF RFP Reading Skill.
Generates a human-readable markdown brief and a structured JSON brief from a canonical extraction JSON.
This presenter expects extraction to follow canonical_extraction_schema.json and to present values in extraction['fields'].
"""

import json
from typing import Dict, Any, List, Tuple
from datetime import datetime


def redact_text(text: str, redact_pii: bool) -> str:
    if not redact_pii:
        return text
    # Very simple placeholder redaction — replace emails and numbers heuristically
    import re
    text = re.sub(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", "[REDACTED_EMAIL]", text, flags=re.I)
    text = re.sub(r"\b\d{5,}\b", "[REDACTED_NUMBER]", text)
    return text


def format_evidence(e: Dict[str, Any]) -> str:
    page = e.get("page")
    snippet = e.get("raw_text", "")
    return f"(p{page}) '{snippet}'" if page else f"'{snippet}'"


def build_tldr(extraction: Dict[str, Any]) -> str:
    # Construct a short 1-2 sentence TL;DR from top items
    # Look for highest-confidence fields that appear relevant (e.g. fields with canonical_name containing 'limit' or 'premium')
    fields = extraction.get('fields', [])
    top = sorted(fields, key=lambda f: f.get('confidence',0), reverse=True)[:3]
    if not top:
        return "No high-confidence issues detected in RFP."
    first = top[0]
    return f"Recommend review: {first.get('field_name','Key item')} (confidence {first.get('confidence',0):.2f})."


def key_facts_section(extraction: Dict[str, Any]) -> List[str]:
    facts = []
    meta = extraction.get("meta", {})
    if meta.get("company_id"):
        facts.append(f"Company: {meta.get('company_id')}")
    if meta.get("uploaded_by"):
        facts.append(f"Uploaded by: {meta.get('uploaded_by')} at {meta.get('uploaded_at')}")
    # Primary coverage limits — find fields matching '*coverage*limit' or canonical names
    for f in extraction.get('fields', []):
        cname = f.get('canonical_name','').lower()
        if 'limit' in cname or 'coverage' in cname:
            amt = f.get('value','')
            page = f.get('page','?')
            conf = f.get('confidence',0)
            unit = f.get('unit') or ''
            facts.append(f"{f.get('field_name')}: {amt} {unit} (p{page}, conf {conf:.2f})")
    return facts


def hidden_and_contradictions(extraction: Dict[str, Any]) -> List[str]:
    items = []
    # hidden conditions: canonical names starting with 'hidden' or similar
    for f in extraction.get('fields', []):
        cname = f.get('canonical_name','')
        if cname and (cname.startswith('hidden') or cname.startswith('sub_limit') or 'hidden' in cname):
            items.append(f"Hidden clause: {f.get('field_name','unnamed')} {format_evidence(f)} (conf {f.get('confidence',0):.2f})")
    # contradictions: if same canonical_name appears multiple times with differing values
    seen = {}
    for f in extraction.get('fields', []):
        key = f.get('canonical_name')
        if not key:
            continue
        if key in seen and seen[key] != f.get('value'):
            items.append(f"Contradiction on {key}: values {seen[key]} vs {f.get('value')} evidence: {format_evidence(f)}")
        seen[key] = f.get('value')
    return items


def recommended_actions(extraction: Dict[str, Any], company_id: str, rfp_id: str, suggested_case_id: str=None, version: int=1, quarantine_info: Dict[str,Any]=None) -> Tuple[List[str], List[Dict[str, str]]]:
    actions = []
    plan = []
    # versioned paths
    pdf_path = f"INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/{company_id}/rfps/{rfp_id}_v{version}.pdf"
    extraction_path = f"INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/{company_id}/rfps/{rfp_id}_v{version}_extraction.json"
    memory_path = f"INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/{company_id}/rfps/{rfp_id}_v{version}.json"
    actions.append(f"Save original PDF to {pdf_path}")
    actions.append(f"Write extraction JSON to {extraction_path}")
    actions.append(f"Add extraction to company memory at {memory_path}")
    plan.append({"action":"save_pdf","path":pdf_path})
    plan.append({"action":"write_extraction","path":extraction_path})
    plan.append({"action":"memory_write","path":memory_path})
    # optional case write
    if suggested_case_id:
        case_path = f"INSURANCE_POLICY_SCRUTINY_AGENT/memory/cases/{suggested_case_id}/record_v{version}.json"
        actions.append(f"Create/update case record at {case_path}")
        plan.append({"action":"case_write","path":case_path})
    # if quarantined, include quarantine action
    if quarantine_info:
        qpath = f"INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/{company_id}/rfps/quarantine/{rfp_id}_v{version}/"
        actions.insert(0, f"Quarantine RFP to {qpath} for manual review")
        plan.insert(0, {"action":"quarantine","path":qpath, "reason": quarantine_info.get("reason_code")})
    return actions, plan


def build_brief(extraction: Dict[str, Any], metadata: Dict[str, Any], redact_pii: bool=True) -> Dict[str, Any]:
    company_id = metadata.get("company_id","COMP-unknown")
    rfp_id = metadata.get("rfp_id","RFP-unknown")
    suggested_case = metadata.get("suggested_case_id")
    version = metadata.get("version", 1)
    quarantine = metadata.get("quarantine")

    # redact textual snippets in raw_text
    for item in extraction.get('fields', []):
        if isinstance(item, dict) and 'raw_text' in item:
            item['raw_text'] = redact_text(item['raw_text'], redact_pii)

    tldr = build_tldr(extraction)
    facts = key_facts_section({"meta": metadata, **extraction})
    flags = hidden_and_contradictions(extraction)
    actions, plan = recommended_actions(extraction, company_id, rfp_id, suggested_case, version, quarantine)

    brief_md_lines = []
    brief_md_lines.append(f"TL;DR: {tldr}")
    brief_md_lines.append("")
    brief_md_lines.append("Details:")
    for f in facts:
        brief_md_lines.append(f"- {f}")
    brief_md_lines.append("")
    brief_md_lines.append(f"Version: v{version}")
    brief_md_lines.append("")
    if quarantine:
        brief_md_lines.append(f"Rejection/Quarantine reason: {quarantine.get('human_readable_reason','See details')}")
        brief_md_lines.append("")
    if flags:
        brief_md_lines.append("Hidden / Contradictions:")
        for fl in flags:
            brief_md_lines.append(f"- {fl}")
        brief_md_lines.append("")
    brief_md_lines.append("Code / Paths:")
    brief_md_lines.append("```")
    for p in [p["path"] for p in plan]:
        brief_md_lines.append(p)
    brief_md_lines.append("```")
    brief_md_lines.append("")
    brief_md_lines.append("Action: Provide explicit Confirm to perform the numbered steps above.")

    brief_md = "\n".join(brief_md_lines)

    structured_brief = {
        "meta": metadata,
        "tldr": tldr,
        "key_facts": facts,
        "flags": flags,
        "plan": plan,
        "version": version,
        "quarantine": quarantine,
        "generated_at": datetime.utcnow().isoformat() + "Z"
    }

    return {"markdown": brief_md, "json": structured_brief}


if __name__ == "__main__":
    # Simple demo (not executed in this environment)
    sample_extraction = {"fields": [{"field_name":"Medical coverage limit","value":1000000,"page":2,"confidence":0.98}], "meta": {}}
    meta = {"company_id":"COMP-1234","rfp_id":"RFP-20260320-a1b2","uploaded_by":"rahul.v","uploaded_at":"2026-03-20T11:00:00Z","version":2}
    brief = build_brief(sample_extraction, meta)
    print(brief["markdown"])
