"""
Rejection and quarantine helpers for pdf_rfp skill.
Handles quarantine records, retry policy, notification stubs and audit entries.
"""

import json
from datetime import datetime
from typing import Dict, Any


def make_quarantine_record(company_id: str, rfp_id: str, reason_code: str, details: Dict[str, Any]) -> Dict[str, Any]:
    record = {
        "company_id": company_id,
        "rfp_id": rfp_id,
        "reason_code": reason_code,
        "human_readable_reason": details.get("human_readable_reason", reason_code),
        "attempted_steps": details.get("attempted_steps", []),
        "retry_count": details.get("retry_count", 0),
        "last_error": details.get("last_error"),
        "suggestions_for_fix": details.get("suggestions_for_fix", []),
        "original_manifest": details.get("original_manifest"),
        "created_at": datetime.utcnow().isoformat() + "Z"
    }
    return record


def save_quarantine(path: str, record: Dict[str, Any]) -> None:
    with open(path, "w") as f:
        json.dump(record, f, indent=2)


def should_retry(record: Dict[str, Any], max_retries: int=3) -> bool:
    return record.get("retry_count", 0) < max_retries


def increment_retry(record: Dict[str, Any]) -> Dict[str, Any]:
    record["retry_count"] = record.get("retry_count", 0) + 1
    record["last_retry_at"] = datetime.utcnow().isoformat() + "Z"
    return record


def notify_uploader(uploader: str, message: str) -> None:
    # Placeholder: integrate with email/slack/notification systems
    print(f"Notify {uploader}: {message}")


def quarantine_summary(record: Dict[str, Any]) -> str:
    return f"Quarantined: {record.get('rfp_id')} reason: {record.get('human_readable_reason')} (retries: {record.get('retry_count')})"
