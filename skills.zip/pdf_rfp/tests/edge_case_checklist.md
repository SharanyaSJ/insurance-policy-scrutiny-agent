# Edge Case Checklist for PDF RFP Skill

- [ ] Scanned image PDFs (no embedded text)
- [ ] Rotated pages
- [ ] Multi-column layouts
- [ ] Tables and annexed schedules
- [ ] Small-font footers and boilerplate
- [ ] Embedded files and attachments
- [ ] Password-protected PDFs
- [ ] Digitally signed PDFs
- [ ] Non-English text / multilingual
- [ ] Extremely large files (>100MB)
- [ ] Malformed/corrupt PDFs
- [ ] OCR failures and fallback engines
- [ ] Cross-document references and external links
- [ ] Duplicate uploads (same checksum)
- [ ] Missing required fields (company_id, coverage limits)

Use this checklist when adding test PDFs to tests/samples/ and when validating new parser changes.
