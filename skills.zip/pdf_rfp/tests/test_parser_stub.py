import unittest

class TestParserStub(unittest.TestCase):
    def test_checksum(self):
        from INSURANCE_POLICY_SCRUTINY_AGENT.skills.pdf_rfp.parser_stub import compute_checksum
        b = b"test"
        h = compute_checksum(b)
        self.assertIsInstance(h, str)
        self.assertEqual(len(h), 64)

if __name__ == '__main__':
    unittest.main()
