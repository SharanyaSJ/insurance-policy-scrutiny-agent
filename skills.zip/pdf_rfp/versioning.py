"""
Versioning helpers for pdf_rfp skill.
Provides immutable write helpers, index updates, checksum and diff utilities.
"""

import json
import os
import hashlib
from typing import Dict, Any
from datetime import datetime


def checksum_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def write_versioned_file(base_path: str, content_bytes: bytes, rfp_id: str) -> Dict[str, Any]:
    """Write content_bytes to base_path/<rfp_id>_vN.ext where N is next version. Return metadata."""
    os.makedirs(base_path, exist_ok=True)
    index_path = os.path.join(base_path, "index.json")
    index = {"versions": []}
    if os.path.exists(index_path):
        with open(index_path, "r") as f:
            index = json.load(f)
    next_v = len(index.get("versions", [])) + 1
    checksum = checksum_bytes(content_bytes)
    filename = f"{rfp_id}_v{next_v}"
    # Determine extension from content assumption (caller provides path)
    out_path = os.path.join(base_path, filename)
    with open(out_path, "wb") as f:
        f.write(content_bytes)
    meta = {"version": next_v, "filename": filename, "checksum": checksum, "created_at": datetime.utcnow().isoformat() + "Z"}
    index.setdefault("versions", []).append(meta)
    with open(index_path, "w") as f:
        json.dump(index, f, indent=2)
    return meta


def write_json_versioned(base_path: str, obj: Dict[str, Any], rfp_id: str, suffix: str=".json") -> Dict[str, Any]:
    os.makedirs(base_path, exist_ok=True)
    index_path = os.path.join(base_path, "index.json")
    index = {"versions": []}
    if os.path.exists(index_path):
        with open(index_path, "r") as f:
            index = json.load(f)
    next_v = len(index.get("versions", [])) + 1
    content = json.dumps(obj, indent=2).encode("utf-8")
    checksum = checksum_bytes(content)
    filename = f"{rfp_id}_v{next_v}{suffix}"
    out_path = os.path.join(base_path, filename)
    with open(out_path, "wb") as f:
        f.write(content)
    meta = {"version": next_v, "filename": filename, "checksum": checksum, "created_at": datetime.utcnow().isoformat() + "Z"}
    index.setdefault("versions", []).append(meta)
    with open(index_path, "w") as f:
        json.dump(index, f, indent=2)
    return meta


def produce_diff(prev_obj: Dict[str, Any], new_obj: Dict[str, Any]) -> Dict[str, Any]:
    diffs = {"changed_fields": [], "confidence_deltas": []}
    for k, v in new_obj.items():
        if k not in prev_obj:
            diffs["changed_fields"].append({"field": k, "change": "added"})
        else:
            if prev_obj[k] != v:
                diffs["changed_fields"].append({"field": k, "old": prev_obj[k], "new": v})
    return diffs
