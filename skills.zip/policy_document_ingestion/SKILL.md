---
name: policy-document-ingestion
description: "Modular orchestrator for ingesting multi-file policy packages (extractors, merger, storage convention, checks & fallback)."
license: Proprietary
---

# Policy Document Ingestion (Orchestrator)

## Overview
Orchestrates modular sub-skills to extract, merge, validate, and store carrier policy documents and endorsements into a canonical policy JSON representation.

## When to use
- On upload of policy packages (multiple files) or arrival of an issued policy for a company

## Upstream / Downstream
- Upstream: document extractors (pdf_rfp analogs for policy docs), OCR engines, company config
- Downstream: three_way_comparison, memory (canonical policy), HITL for cases requiring manual resolution

## Core orchestration steps
1) Create ingestion manifest and staging folder
2) Select appropriate extractor for each file (pdf, docx, tiff) via document_extractor_interface
3) Extract per-file structured content + metadata
4) Run multi_doc_merger_interface to create canonical policy JSON (preserve versions)
5) Run checks_and_fallback to validate required sections and fill gaps or escalate to HITL
6) Persist canonical policy artifact to data/ and optionally propose memory write (via HITL)

## Outputs
- Staging manifest and per-file extraction artifacts
- Canonical policy JSON under data/companies/<COMPANY_ID>/policies/<POLICY_ID>/policy_vN.json
- Merge logs and provenance

## Failure modes (detection & fallback)
- extractor_failure: extractor returns error for file type → retry alternative extractor, then quarantine if persistent
- merge_conflict: overlapping sections with incompatible values → create merge_conflict report and escalate to HITL
- missing_required_sections: run fallback heuristics; if unresolved, mark as incomplete and require HITL
- versioning_conflict: same policy_id with unexpected version → preserve both and create diff, require human reconciliation
- storage_write_error: retry + alert; do not mark ingestion complete until writes succeed

## QA & checks
- Validate canonical policy JSON against the policy schema (project policy schema)
- Ensure manifest lists every file with checksum and extractor version

## Developer notes
- Keep heavy extraction logic in sub-skills and make this file a deterministic orchestrator responsible for provenance and gating.
