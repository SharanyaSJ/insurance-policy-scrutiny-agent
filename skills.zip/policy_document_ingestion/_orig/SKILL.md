---
name: policy-document-ingestion
description: "Index for modular Policy Document Ingestion capability. Minimal orchestration only."
license: Proprietary
---

# SKILL

## Overview
Index for modular Policy Document Ingestion capability. Minimal orchestration only.

## When To Use
- See detailed skill description below when triggers apply.

## Step by Step Process
1. name: policy_document_ingestion
summary: "Index for modular Policy Document Ingestion capability. Minimal orchestration only."
---

2. # Policy Document Ingestion (Index)

3. This file is intentionally minimal. Real logic is distributed across sub-skills to avoid concentrating all behavior in a single file.

4. See sub-skills:
- CORE_AGENT_SKILLS/policy_document_ingestion/core/SKILL.md
- CORE_AGENT_SKILLS/policy_document_ingestion/document_extractor_interface/SKILL.md
- CORE_AGENT_SKILLS/policy_document_ingestion/multi_doc_merger_interface/SKILL.md
- CORE_AGENT_SKILLS/policy_document_ingestion/storage_convention/SKILL.md
- CORE_AGENT_SKILLS/policy_document_ingestion/checks_and_fallback/SKILL.md

5. The core orchestrator should only:
- create an ingestion manifest
- invoke sub-skill contracts
- persist the final entity name and manifest to company memory

6. Do not place extraction, merge, storage, or fallback logic in this file.


## Rules & Constraints
- Preserve original logic and do not write to memory without confirmation when applicable.

## Quick Reference
| Operation | Path / Note |
|---|---:|
| Primary files | see skill folder |
