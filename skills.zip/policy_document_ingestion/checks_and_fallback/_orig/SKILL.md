---
name: checks_and_fallback
summary: "Business checks, override detection rules, and fallback strategies when extraction or merging fails."
---

# Checks and Fallbacks

Checks
- Clause presence: for each addendum clause with an explicit override reference, verify base clause exists by clause_number or semantic match (threshold configurable)
- Override detection: look for override language and compute token-diff + semantic change to classify override_type
- Coverage consistency: validate dates and numeric fields across sources

Failure modes to handle
- OCR_FAIL: scanned document OCR unsuccessful or low confidence
- PARSE_FAIL: extractor fails to segment clauses reliably
- ALIGN_FAIL / CONFLICT_DETECTED: merger cannot unambiguously map clauses

Fallback strategy (ordered)
1. Retry automated steps with relaxed thresholds (lower similarity threshold, alternate OCR engine) and log attempt.
2. If still failing, produce a compact failure manifest saved to storage_convention path containing: error codes, short summaries, top-K candidate matches for manual review, and links to artifact files.
3. Create a human-review task: include exact file paths, short instructions, and a suggested resolution (e.g., accept addendum clause as new, manual mapping to clause X).
4. If user-approved automatic fallback is enabled (opt-in), run a best-effort heuristic merge that marks uncertain mappings with low confidence and appends a "requires_review" flag in final JSON.
5. Always persist raw artifacts (OCR text, diff files) and the failure manifest for audit.

Failure manifest structure (compact)
{
  "policy_id": "",
  "status": "failed",
  "errors": ["OCR_FAIL","ALIGN_FAIL"],
  "hints": [ {"type":"candidate_match","addendum_clause_id":"A1","candidates":[{"base_clause_id":"B7","score":0.63},...] } ],
  "artifact_paths": ["userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/policies/<policy_id>/ocr/..."],
  "next_steps": "Human review required or enable auto-fallback"
}

Security
- Failure manifests may contain sensitive snippets; store them inside workspace only and restrict downstream export.
