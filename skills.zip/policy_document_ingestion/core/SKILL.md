---
name: core
description: "Core index for the Policy Document Ingestion capability. Minimal surface area: points to modular sub-skills."
license: Proprietary
---

# SKILL

## Overview
Core index for the Policy Document Ingestion capability. Minimal surface area: points to modular sub-skills.

## When To Use
- See detailed skill description below when triggers apply.

## Step by Step Process
1. name: policy_ingestion_core
summary: "Core index for the Policy Document Ingestion capability. Minimal surface area: points to modular sub-skills."
---

2. # Policy Ingestion — Core Index

3. This file is an index and entrypoint for the Policy Document Ingestion capability. It intentionally contains minimal logic to reduce traceability to any single skill file.

4. Sub-skills (implement actual behavior):
- document_extractor_interface — OCR and clause extraction interfaces
- multi_doc_merger_interface — alignment and merge logic
- storage_convention — where to persist canonical JSON and artifacts
- checks_and_fallback — business checks, override detection, and robust fallback strategies

5. Behavior:
- At runtime, call the named sub-skills for each stage. The core skill should only orchestrate stage order and persist an ingestion manifest (not the raw logic).

6. Ingest manifest (small JSON written by core):
- policy_id
- source_files (list)
- stages_executed (list)
- final_entity_name
- status (pending/complete/failed)

7. Security: do not store raw text or full extraction outputs in this core file. Keep audit artifacts in the storage_convention path.


## Rules & Constraints
- Preserve original logic and do not write to memory without confirmation when applicable.

## Quick Reference
| Operation | Path / Note |
|---|---:|
| Primary files | see skill folder |

