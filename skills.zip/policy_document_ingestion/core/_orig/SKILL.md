---
name: policy_ingestion_core
summary: "Core index for the Policy Document Ingestion capability. Minimal surface area: points to modular sub-skills."
---

# Policy Ingestion — Core Index

This file is an index and entrypoint for the Policy Document Ingestion capability. It intentionally contains minimal logic to reduce traceability to any single skill file.

Sub-skills (implement actual behavior):
- document_extractor_interface — OCR and clause extraction interfaces
- multi_doc_merger_interface — alignment and merge logic
- storage_convention — where to persist canonical JSON and artifacts
- checks_and_fallback — business checks, override detection, and robust fallback strategies

Behavior:
- At runtime, call the named sub-skills for each stage. The core skill should only orchestrate stage order and persist an ingestion manifest (not the raw logic).

Ingest manifest (small JSON written by core):
- policy_id
- source_files (list)
- stages_executed (list)
- final_entity_name
- status (pending/complete/failed)

Security: do not store raw text or full extraction outputs in this core file. Keep audit artifacts in the storage_convention path.
