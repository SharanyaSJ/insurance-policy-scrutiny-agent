---
name: document-extractor-interface
description: "Interface specification for document_extractor used in policy ingestion. Contains only contract and error-handling guidance."
license: Proprietary
---

# SKILL

## Overview
Interface specification for document_extractor used in policy ingestion. Contains only contract and error-handling guidance.

## When To Use
- See detailed skill description below when triggers apply.

## Step by Step Process
1. name: document_extractor_interface
summary: "Interface specification for document_extractor used in policy ingestion. Contains only contract and error-handling guidance."
---

2. # Document Extractor Interface

3. Purpose
- Define the minimal contract the document_extractor skill must satisfy. Keep implementation separate.

4. API (contract)
- extract_text(file_path) -> {text: string, ocr_confidence: float, ocr_meta: dict}
- extract_clauses(text) -> [{clause_id, title, number, type, text, normalized_text, extracted_fields, location, confidence}]
- extract_metadata(text) -> {policy_id, insurer, insured, issue_date, effective_date, expiry_date}

5. Error handling
- Must return structured errors with codes: OCR_FAIL, PARSE_FAIL, NO_POLICY_ID
- On recoverable errors, return partial outputs + error codes

6. Logging
- Emit minimal logs to the ingestion manifest only (no raw text). Store raw OCR text to storage_convention path.


## Rules & Constraints
- Preserve original logic and do not write to memory without confirmation when applicable.

## Quick Reference
| Operation | Path / Note |
|---|---:|
| Primary files | see skill folder |

