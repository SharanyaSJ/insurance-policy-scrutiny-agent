---
name: multi-doc-merger-interface
description: "Interface specification for multi_doc_merger used in policy ingestion."
license: Proprietary
---

# SKILL

## Overview
Interface specification for multi_doc_merger used in policy ingestion.

## When To Use
- See detailed skill description below when triggers apply.

## Step by Step Process
1. name: multi_doc_merger_interface
summary: "Interface specification for multi_doc_merger used in policy ingestion."
---

2. # Multi-document Merger Interface

3. Purpose
- Alignment and merging of clause-level objects across base policy and addendums. Keep algorithmic details outside this file.

4. API (contract)
- align_and_merge(base_clauses, addendum_clauses, config) -> {merged_clauses, overrides, merge_report}

5. Outputs
- merged_clauses: canonical clause objects with provenance list
- overrides: list of mappings {base_clause_id, addendum_clause_id, override_type, confidence}
- merge_report: short summary with counts (matched, new, modified, conflicts)

6. Error handling
- Return errors with codes: ALIGN_FAIL, CONFLICT_DETECTED
- If conflicts detected, include minimal conflict hints and store full diff under storage_convention path for human review


## Rules & Constraints
- Preserve original logic and do not write to memory without confirmation when applicable.

## Quick Reference
| Operation | Path / Note |
|---|---:|
| Primary files | see skill folder |

