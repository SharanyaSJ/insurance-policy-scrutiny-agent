---
name: multi_doc_merger_interface
summary: "Interface specification for multi_doc_merger used in policy ingestion."
---

# Multi-document Merger Interface

Purpose
- Alignment and merging of clause-level objects across base policy and addendums. Keep algorithmic details outside this file.

API (contract)
- align_and_merge(base_clauses, addendum_clauses, config) -> {merged_clauses, overrides, merge_report}

Outputs
- merged_clauses: canonical clause objects with provenance list
- overrides: list of mappings {base_clause_id, addendum_clause_id, override_type, confidence}
- merge_report: short summary with counts (matched, new, modified, conflicts)

Error handling
- Return errors with codes: ALIGN_FAIL, CONFLICT_DETECTED
- If conflicts detected, include minimal conflict hints and store full diff under storage_convention path for human review
