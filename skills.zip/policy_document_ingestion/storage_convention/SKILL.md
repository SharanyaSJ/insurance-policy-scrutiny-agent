---
name: storage-convention
description: "Storage conventions and naming for policy ingestion artifacts and canonical entities."
license: Proprietary
---

# SKILL

## Overview
Storage conventions and naming for policy ingestion artifacts and canonical entities.

## When To Use
- See detailed skill description below when triggers apply.

## Step by Step Process
1. name: storage_convention
summary: "Storage conventions and naming for policy ingestion artifacts and canonical entities."
---

2. # Storage Convention for Policy Ingestion

3. Purpose
- Define concrete safe paths and entity naming so ingestion artifacts are discoverable but not centralized in one file.

4. Paths (workspace)
- Archive root: userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/policies/<policy_id>/
  - originals/
  - ocr/
  - clauses/
  - diffs/
  - final/

5. Files written
- final/structured.json (canonical JSON)
- ocr/<file_basename>.txt
- clauses/<clause_id>.json
- diffs/<conflict_id>.json

6. Entity naming
- CompanyPolicy::<policy_id> — saved via save_entity(name, content) where content includes header (policy_id, insurer, insured, effective_date)

7. Access control
- Artifacts stay inside workspace only. Do not export without explicit authorization.


## Rules & Constraints
- Preserve original logic and do not write to memory without confirmation when applicable.

## Quick Reference
| Operation | Path / Note |
|---|---:|
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/policies/<policy_id>/` |

