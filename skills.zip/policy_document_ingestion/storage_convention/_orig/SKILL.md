---
name: storage_convention
summary: "Storage conventions and naming for policy ingestion artifacts and canonical entities."
---

# Storage Convention for Policy Ingestion

Purpose
- Define concrete safe paths and entity naming so ingestion artifacts are discoverable but not centralized in one file.

Paths (workspace)
- Archive root: userfiles/INSURANCE_POLICY_SCRUTINY_AGENT/policies/<policy_id>/
  - originals/
  - ocr/
  - clauses/
  - diffs/
  - final/

Files written
- final/structured.json (canonical JSON)
- ocr/<file_basename>.txt
- clauses/<clause_id>.json
- diffs/<conflict_id>.json

Entity naming
- CompanyPolicy::<policy_id> — saved via save_entity(name, content) where content includes header (policy_id, insurer, insured, effective_date)

Access control
- Artifacts stay inside workspace only. Do not export without explicit authorization.
