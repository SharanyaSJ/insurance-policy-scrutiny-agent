---
name: quote-sheet
description: "Ingest, validate, extract, and compare insurer quote sheets against RFP baselines. Includes extraction variants and failure modes."
license: Proprietary
---

# Quote Sheet Skill — Insurance Policy Scrutiny Agent

## Overview
Ingest, validate, extract, and compare insurer quote sheets against RFP baselines. Supports two extraction variants: A (conservative) and B (aggressive).

## When to use
- On arrival of a carrier quote (PDF/XLSX/JSON) for a company
- Before initiating RFP↔Quote comparisons

## Upstream / Downstream
- Upstream: raw quote files (PDF/XLSX), OCR, company config, memory RFP baseline
- Downstream: rfp_quote_compare, three_way_comparison, HITL for confirmation, memory (on Confirm)

## Core steps
1) Upload & validate: basic file checks, password/damage detection, quick schema sanity
2) Read & extract: OCR if needed; extract coverages, premiums, exclusions, endorsements, per-field confidences; generate vA/vB
3) Compare to RFP baseline: produce comparison report and risk score
4) Present for HITL Confirm before writes

## Outputs
- Staging: output/pending_quotes/<COMPANY_ID>/<QUOTE_ID>_extraction_vA.json
- Canonical (on Confirm): data/companies/<COMPANY_ID>/quotes/<QUOTE_ID>_vN.pdf and memory entries

## Storage & Path Rules (MANDATORY)
- All uploaded quote files MUST be saved to: data/companies/<COMPANY_ID>/quotes/
- All extraction artifacts and outputs MUST be written to the project outputs folder under: output/comparisons/<COMPANY_ID>/<CASE_ID>/ or output/pending_quotes/<COMPANY_ID>/.
- No files may be written outside the INSURANCE_POLICY_SCRUTINY_AGENT project folder. The orchestrator will block any write target outside the approved data/ or output/ directories.
- On ingest failure to save to data/: abort processing and notify the uploader with the message: "File could not be saved. Please retry upload to the project data folder."

## Strict Compliance Output Format
- All RFP↔Quote↔Policy comparisons MUST use the project-wide STRICT COMPLIANCE format.
- Template path: INSURANCE_POLICY_SCRUTINY_AGENT/skills/utils/STRICT_COMPLIANCE_TEMPLATE.md
- Comparison generators (vA/vB) must produce the "FLAG TABLE" where each row is exactly one atomic flag as defined by the project's CORE RULES.
- Do NOT emit analyst prose in final comparison artifacts. Emit only the SUMMARY and FLAG TABLE as plain text/markdown.

## Failure modes (detection & fallbacks)
- corrupt_or_unreadable: quarantine and notify uploader
- password_protected: mark and quarantine with instructions
- table_parsing_errors: fallback to manual table heuristics and flag for HITL
- currency_mismatch: normalize using company defaults or require human confirmation
- conflicting_premium_calculation: flag and require HITL to verify math
- large_or_multi-file_quote: split and ingest parts; create a merged manifest
- persistence_failure: retry + alert; do not proceed to downstream steps until resolved

## QA & validation
- Verify extraction JSON validates against the project's quote extraction template
- Cross-check premium totals to ensure arithmetic is consistent; place mismatch in comparison report

## Memory interaction
- Candidate memory writes must include schema_version and conform to ingest_metadata.schema.json
- Always route candidate writes through HITL unless auto_update enabled for company bucket

