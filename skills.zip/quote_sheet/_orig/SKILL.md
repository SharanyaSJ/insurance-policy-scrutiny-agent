---
name: quote-sheet
description: "Skills to upload, validate, extract, and compare insurer quote sheets against RFP baselines. Includes two extraction versions: A (clean) and B (with deviations)."
license: Proprietary
---

# Quote Sheet Skills — Insurance Policy Scrutiny Agent

## Overview
Skills to upload, validate, extract, and compare insurer quote sheets against RFP baselines. Includes two extraction versions: A (clean) and B (with deviations).

## When To Use
- When a quote PDF is uploaded for a company
- When comparing quote sheets to RFP baselines
- 
## Step by Step Process
1. title: "Quote Sheet Skills — Insurance Policy Scrutiny Agent"
summary: "Skills to upload, validate, extract, and compare insurer quote sheets against RFP baselines. Includes two extraction versions: A (clean) and B (with deviations)."
read_when:
  - When a quote PDF is uploaded for a company
  - When comparing quote sheets to RFP baselines
---

2. # Quote Sheet Skills

3. Purpose
- Provide a small skill set to ingest insurer quote sheets, validate them, extract structured data, and compare the extraction to an RFP baseline stored in memory.
- Enforce strict HITL review at every write or memory update.
- Support two extraction "versions":
  - Version A: Clean extraction (expected well-formed quote sheet).
  - Version B: Aggressive extraction that attempts to annotate deviations and hidden conditions even when the quote is messy.

4. Skill breakdown
- Skill 1 — Upload & Validate (upload_validate.py)
  - Question: "Is this document usable?"
  - Actions: basic file checks, filesize limits, password/damage detection, quick schema sanity check (presence of key fields), and either Accept or Quarantine with clear reasons.

5. - Skill 2 — Read & Extract (read_extract.py)
  - Question: "What does this document say?"
  - Actions: run OCR if needed; extract Coverage summary, Premium values, Key terms (co-pay, room rent, deductibles), Add-ons, exclusions, hidden conditions, and other clause-level details. Attach per-field confidence scores. Produce two variants (A/B) depending on desired aggressiveness.
  - Output: structured extraction JSON saved only after HITL Confirm.

6. - Skill 3 — Compare (compare.py)
  - Question: "How does this match the RFP?"
  - Actions: pull RFP baseline from memory, pull Quote extraction from memory (or staged extraction), perform field-by-field comparison, flag deviations (missing clause, lower limit, hidden condition), compute a risk score, and produce a comparison report for HITL decision.
  - Output: comparison report saved only after HITL Confirm.

7. Paths & naming
- Staging briefs and extractions:
  INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_quotes/<COMPANY_ID>/<QUOTE_ID>_brief.md
  INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_quotes/<COMPANY_ID>/<QUOTE_ID>_extraction_vA.json
  INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_quotes/<COMPANY_ID>/<QUOTE_ID>_extraction_vB.json

8. - Canonical (on Confirm):
  INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/<COMPANY_ID>/quotes/<QUOTE_ID>_vN.pdf
  INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/<COMPANY_ID>/quotes/<QUOTE_ID>_vN.json
  INSURANCE_POLICY_SCRUTINY_AGENT/memory/cases/<CASE_ID>/record_vN.json

9. HITL and audit
- All skills must call the HITL skill for any write action. Present a numbered action plan in the exact required format and wait for explicit "Confirm". Partial confirms allowed (e.g., "Confirm 1 and 3").
- All writes append to audit.log with {action, by, timestamp, session_id, confidence, source}.

10. Templates & examples
- Use templates in templates/ for extraction formats (A and B), and brief_template.md for human presentation.


## Rules & Constraints
- Preserve original logic and do not write to memory without confirmation when applicable.

## Quick Reference
| Operation | Path / Note |
|---|---:|
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_quotes/<COMPANY_ID>/<QUOTE_ID>_brief.md` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_quotes/<COMPANY_ID>/<QUOTE_ID>_extraction_vA.json` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_quotes/<COMPANY_ID>/<QUOTE_ID>_extraction_vB.json` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/<COMPANY_ID>/quotes/<QUOTE_ID>_vN.pdf` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/<COMPANY_ID>/quotes/<QUOTE_ID>_vN.json` |
| See example path | `INSURANCE_POLICY_SCRUTINY_AGENT/memory/cases/<CASE_ID>/record_vN.json` |