TL;DR: {{tldr}}

Details:
- Company: {{company_id}}
- Quote ID: {{quote_id}}
- Version: {{version}}
- Uploaded by: {{uploaded_by}} at {{uploaded_at}}

Coverage summary:
{{#coverage_summary}}
- {{coverage_type}}: {{limit}} (p{{page}}, conf {{confidence}})
{{/coverage_summary}}

Premiums:
{{#premium_values}}
- {{item}}: {{amount}} {{currency}} (conf {{confidence}})
{{/premium_values}}

Key terms:
- Copay: {{key_terms.copay}}
- Room rent: {{key_terms.room_rent}}
- Deductible: {{key_terms.deductible}}

Injected issues (if any):
{{#injected_issues}}
- {{.}}
{{/injected_issues}}

Hidden / Flags:
{{#hidden_conditions}}
- (p{{page}}) {{snippet}} (conf {{confidence}})
{{/hidden_conditions}}

Code / Paths:
```
{{#paths}}
{{.}}
{{/paths}}
```

Action: Provide explicit Confirm to save this extraction to memory.
