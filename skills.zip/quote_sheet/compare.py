"""
Skill 3 — Compare
Compares a quote canonical extraction against the RFP baseline from memory and produces a comparison report with deviations and risk scoring.
Inputs/outputs use canonical extraction format: each extraction dict contains 'fields' list of canonical field objects.
"""

from typing import Dict, Any, List, Tuple
from datetime import datetime
from .normalize import normalize_key_terms


def _to_number(val) -> float:
    try:
        return float(str(val).replace(',','').replace('$',''))
    except Exception:
        return None


def _find_fields_by_pred(fields: List[Dict[str,Any]], pred) -> List[Dict[str,Any]]:
    return [f for f in fields if pred(f)]


def compare_fields(rfp: Dict[str,Any], quote: Dict[str,Any], tolerance_percent: float=0.0) -> Dict[str,Any]:
    """Field-by-field comparison. Returns a report dict with deviations and a simple risk score.
    tolerance_percent: allowed lower difference (e.g., 0.05 allows quote up to 5% lower than RFP without flagging)
    """
    report = {
        "quote_id": quote.get('quote_id'),
        "company_id": quote.get('company_id'),
        "compared_at": datetime.utcnow().isoformat() + 'Z',
        "deviations": [],
        "summary": {},
        "risk_score": 0.0,
        "checks": {
            "missing_rfp_fields": [],
            "new_conditions": [],
            "lower_than_rfp": []
        }
    }
    score = 0.0

    # Normalize key terms for both RFP and quote if present (legacy support)
    # key_terms may no longer exist; skip if absent

    rfp_fields = rfp.get('extraction', {}).get('fields', []) if rfp.get('extraction') else []
    quote_fields = quote.get('extraction', {}).get('fields', []) if quote.get('extraction') else []

    # 1) Is every RFP coverage field present in Quote? Identify coverage-like fields by canonical_name or field_name keywords
    def is_coverage_field(f):
        cname = (f.get('canonical_name') or '').lower()
        fname = (f.get('field_name') or '').lower()
        return ('coverage' in cname) or ('coverage' in fname) or ('limit' in cname) or ('limit' in fname)

    rfp_covs = _find_fields_by_pred(rfp_fields, is_coverage_field)
    q_covs = _find_fields_by_pred(quote_fields, is_coverage_field)

    rfp_types = { (r.get('canonical_name') or r.get('field_name')) for r in rfp_covs }
    q_types = { (q.get('canonical_name') or q.get('field_name')) for q in q_covs }

    for rtype in rfp_types:
        if rtype not in q_types:
            report['checks']['missing_rfp_fields'].append(rtype)
            report['deviations'].append({'type':'missing_clause','coverage_type': rtype})
            score += 0.4

    # 2) Any new conditions introduced in quote? hidden conditions identified by canonical_name containing 'hidden' or similar
    def is_hidden_cond(f):
        cname = (f.get('canonical_name') or '').lower()
        fname = (f.get('field_name') or '').lower()
        return ('hidden' in cname) or ('hidden' in fname) or ('sub_limit' in cname) or ('exclusion' in cname) or ('exclusion' in fname)

    rfp_conditions = set()
    for rr in _find_fields_by_pred(rfp_fields, is_hidden_cond):
        txt = (rr.get('raw_text') or '').strip().lower()
        if txt:
            rfp_conditions.add(txt)
    for qc in _find_fields_by_pred(quote_fields, is_hidden_cond):
        txt = (qc.get('raw_text') or '').strip().lower()
        if txt and txt not in rfp_conditions:
            report['checks']['new_conditions'].append({'snippet': txt, 'confidence': qc.get('confidence')})
            report['deviations'].append({'type':'new_condition','snippet': txt, 'confidence': qc.get('confidence')})
            score += 0.25

    # 3) Any numeric value lower than RFP? match coverage types by canonical_name
    for r in rfp_covs:
        for q in q_covs:
            r_name = r.get('canonical_name') or r.get('field_name')
            q_name = q.get('canonical_name') or q.get('field_name')
            if r_name == q_name:
                rlim = _to_number(r.get('value'))
                qlim = _to_number(q.get('value'))
                if rlim is not None and qlim is not None:
                    allowed = rlim * (1.0 - tolerance_percent)
                    if qlim < allowed:
                        report['checks']['lower_than_rfp'].append({'coverage_type': r_name, 'rfp_limit': r.get('value'), 'quote_limit': q.get('value')})
                        report['deviations'].append({'type':'lower_limit_than_rfp','coverage_type': r_name,'rfp_limit': r.get('value'),'quote_limit': q.get('value')})
                        score += 0.3

    # Premium comparison - look for canonical annual_premium or premium fields
    def is_premium_field(f):
        cname = (f.get('canonical_name') or '').lower()
        fname = (f.get('field_name') or '').lower()
        return 'premium' in cname or 'premium' in fname or f.get('field_id','').startswith('premium')

    rfp_prem_vals = [ _to_number(f.get('value')) or 0 for f in rfp_fields if is_premium_field(f) ]
    q_prem_vals = [ _to_number(f.get('value')) or 0 for f in quote_fields if is_premium_field(f) ]
    rfp_prem = sum(rfp_prem_vals)
    q_prem = sum(q_prem_vals)
    try:
        if q_prem > 0 and rfp_prem > 0:
            if q_prem > rfp_prem * 1.2:
                report['deviations'].append({'type':'premium_higher_than_expected','rfp_premium': rfp_prem,'quote_premium': q_prem})
                score += 0.2
            elif q_prem < rfp_prem * 0.8:
                report['deviations'].append({'type':'premium_much_lower_than_expected','rfp_premium': rfp_prem,'quote_premium': q_prem})
                score += 0.1
    except Exception:
        pass

    report['risk_score'] = min(1.0, score)
    report['summary'] = {'deviation_count': len(report['deviations']), 'risk_score': report['risk_score'], 'checks': report['checks']}
    return report


def build_comparison_brief(report: Dict[str,Any]) -> Dict[str,Any]:
    lines = []
    lines.append(f"TL;DR: Comparison produced {report.get('summary',{}).get('deviation_count',0)} deviations; risk_score={report.get('risk_score'):.2f}")
    lines.append("")
    lines.append("Details:")
    checks = report.get('summary',{}).get('checks',{})
    lines.append(f"- Missing RFP fields: {checks.get('missing_rfp_fields',[])}")
    lines.append(f"- New conditions: {checks.get('new_conditions',[])}")
    lines.append(f"- Lower-than-RFP: {checks.get('lower_than_rfp',[])}")
    lines.append("")
    for d in report.get('deviations', [])[:20]:
        lines.append(f"- {d.get('type')}: { {k:v for k,v in d.items() if k!='type'} }")
    lines.append("")
    lines.append("Code / Paths:")
    lines.append("```")
    lines.append(f"INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/{report.get('company_id')}/quotes/")
    lines.append("```")
    lines.append("")
    lines.append("Action: Provide explicit Confirm to record this comparison and decision to memory.")
    return {"markdown": "\n".join(lines), "json": report}


if __name__ == '__main__':
    # demo usage
    rfp = {'extraction': {'fields': [{'field_id':'f1','canonical_name':'medical_coverage_limit','field_name':'Medical limit','value':1000000},{'field_id':'p1','canonical_name':'annual_premium','field_name':'Annual premium','value':12000}]}}
    quote = {'quote_id':'QUOTE-20260320-aaaa','company_id':'COMP-1234','extraction': {'fields': [{'field_id':'q1','canonical_name':'medical_coverage_limit','field_name':'Coverage limit','value':800000},{'field_id':'q2','canonical_name':'annual_premium','field_name':'Annual premium','value':13000}]}}
    rep = compare_fields(rfp, quote)
    brief = build_comparison_brief(rep)
    print(brief['markdown'])
