"""
Normalization helpers for quote_sheet skill.
Provides mappings for common insurance term synonyms and utility functions.
"""

from typing import Dict, Any

# Simple normalization map - extend as needed
TERM_MAP = {
    # co-pay synonyms
    "co-pay": "member_contribution",
    "copay": "member_contribution",
    "member contribution": "member_contribution",
    # room rent variants
    "room rent": "room_rent",
    "room-rent": "room_rent",
    "room charge": "room_rent",
    "room_type": "room_rent",
    # deductible
    "deductible": "deductible",
    "excess": "deductible",
}


def normalize_term(term: str) -> str:
    if not term:
        return ""
    t = term.strip().lower()
    return TERM_MAP.get(t, t.replace(' ', '_'))


def normalize_key_terms(key_terms: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of key_terms with normalized keys and values where applicable."""
    normalized = {}
    for k, v in key_terms.items():
        nk = normalize_term(k)
        normalized[nk] = v
    return normalized


def detect_hidden_conditions_from_text(text: str) -> list:
    """Heuristic detection of hidden conditions from a block of text.
    Returns list of detected snippets.
    """
    snippets = []
    if not text:
        return snippets
    lowered = text.lower()
    triggers = ["subject to", "sub-limit", "sub limit", "unless otherwise agreed", "to the extent of", "may not be covered"]
    for trig in triggers:
        if trig in lowered:
            # extract a short window around first occurrence
            idx = lowered.find(trig)
            start = max(0, idx - 40)
            end = min(len(text), idx + 120)
            snippets.append(text[start:end].strip())
    return snippets
