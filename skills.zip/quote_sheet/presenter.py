"""
Presenter for Quote Sheet skills. Builds human-readable brief and structured JSON brief for quotes.
Now expects canonical extraction format: extraction['fields'] list of canonical field objects.
"""

import json
from datetime import datetime
from typing import Dict, Any, List, Tuple


def _is_coverage_field(f):
    cname = (f.get('canonical_name') or '').lower()
    fname = (f.get('field_name') or '').lower()
    return ('coverage' in cname) or ('coverage' in fname) or ('limit' in cname) or ('limit' in fname)


def _is_premium_field(f):
    cname = (f.get('canonical_name') or '').lower()
    fname = (f.get('field_name') or '').lower()
    return 'premium' in cname or 'premium' in fname or f.get('field_id','').startswith('premium')


def _is_hidden(f):
    cname = (f.get('canonical_name') or '').lower()
    fname = (f.get('field_name') or '').lower()
    return ('hidden' in cname) or ('hidden' in fname) or ('sub_limit' in cname) or ('exclusion' in cname)


def build_quote_tldr(extraction: Dict[str, Any]) -> str:
    fields = extraction.get('fields', [])
    covs = [f for f in fields if _is_coverage_field(f)]
    if not covs:
        return "No coverage items detected."
    top = sorted(covs, key=lambda f: f.get('confidence',0), reverse=True)[0]
    return f"Quote includes {top.get('field_name','coverage')} with limit {top.get('value','unknown')} (conf {top.get('confidence',0):.2f})."


def build_key_facts(extraction: Dict[str, Any], metadata: Dict[str, Any]) -> List[str]:
    facts = []
    facts.append(f"Company: {metadata.get('company_id')}")
    facts.append(f"Quote ID: {metadata.get('quote_id')}")
    facts.append(f"Version: {metadata.get('version')}")
    up = metadata.get('uploaded_by')
    at = metadata.get('uploaded_at')
    if up:
        facts.append(f"Uploaded by: {up} at {at}")
    # premiums
    for p in [f for f in extraction.get('fields', []) if _is_premium_field(f)][:5]:
        facts.append(f"Premium: {p.get('field_name','premium')} = {p.get('value','')} {p.get('unit','')} (conf {p.get('confidence',0):.2f})")
    return facts


def build_flags(extraction: Dict[str, Any]) -> List[str]:
    flags = []
    for h in [f for f in extraction.get('fields', []) if _is_hidden(f)]:
        flags.append(f"Hidden condition (p{h.get('page','?')}): {h.get('raw_text','')} (conf {h.get('confidence',0):.2f})")
    for ex in [f for f in extraction.get('fields', []) if 'exclusion' in (f.get('canonical_name') or '').lower()][:5]:
        flags.append(f"Exclusion: {ex.get('raw_text','')} (p{ex.get('page','?')})")
    return flags


def recommended_actions(metadata: Dict[str, Any], version: str='A') -> Tuple[List[str], List[Dict[str,str]]]:
    actions = []
    plan = []
    company_id = metadata.get('company_id')
    quote_id = metadata.get('quote_id')
    pdf_path = f"INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/{company_id}/quotes/{quote_id}_v{version}.pdf"
    extraction_path = f"INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/{company_id}/quotes/{quote_id}_v{version}_extraction.json"
    memory_path = f"INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/{company_id}/quotes/{quote_id}_v{version}.json"
    actions.append(f"Save original PDF to {pdf_path}")
    actions.append(f"Write extraction JSON to {extraction_path}")
    actions.append(f"Add extraction to company memory at {memory_path}")
    plan.append({"action":"save_pdf","path":pdf_path})
    plan.append({"action":"write_extraction","path":extraction_path})
    plan.append({"action":"memory_write","path":memory_path})
    return actions, plan


def build_brief(extraction: Dict[str, Any], metadata: Dict[str, Any], redact_pii: bool=True) -> Dict[str, Any]:
    tldr = build_quote_tldr(extraction)
    facts = build_key_facts(extraction, metadata)
    flags = build_flags(extraction)
    actions, plan = recommended_actions(metadata, metadata.get('version','A'))

    # include normalized key terms if present (legacy support)
    normalized_terms = (extraction.get('meta') or {}).get('key_terms_normalized') or {}

    markdown_lines = []
    markdown_lines.append(f"TL;DR: {tldr}")
    markdown_lines.append("")
    markdown_lines.append("Details:")
    for f in facts:
        markdown_lines.append(f"- {f}")
    markdown_lines.append("")
    if normalized_terms:
        markdown_lines.append("Normalized terms:")
        for k, v in normalized_terms.items():
            markdown_lines.append(f"- {k}: {v}")
        markdown_lines.append("")
    if flags:
        markdown_lines.append("Hidden / Flags:")
        for fl in flags:
            markdown_lines.append(f"- {fl}")
        markdown_lines.append("")
    markdown_lines.append("Code / Paths:")
    markdown_lines.append("```")
    for p in [p['path'] for p in plan]:
        markdown_lines.append(p)
    markdown_lines.append("```")
    markdown_lines.append("")
    markdown_lines.append("Action: Provide explicit Confirm to save this extraction to memory.")

    structured = {
        'meta': metadata,
        'tldr': tldr,
        'key_facts': facts,
        'normalized_terms': normalized_terms,
        'flags': flags,
        'plan': plan,
        'generated_at': datetime.utcnow().isoformat() + 'Z'
    }
    return {"markdown": "\n".join(markdown_lines), "json": structured}


if __name__ == '__main__':
    sample = {'fields': [{'field_id':'coverage_limit:medical','canonical_name':'medical_coverage_limit','field_name':'Medical coverage','value':1000000,'unit':'USD','page':2,'confidence':0.98},{'field_id':'premium:annual','canonical_name':'annual_premium','field_name':'Annual premium','value':12000,'unit':'USD','page':2,'confidence':0.95},{'field_id':'hidden:sub_limit','canonical_name':'sub_limit_hidden','field_name':'Sub-limit','value':'subject to sub-limit of 100k','page':5,'confidence':0.86}], 'meta':{}}
    meta = {'company_id':'COMP-1234','quote_id':'QUOTE-20260320-aaaa','version':'B','uploaded_by':'rahul.v','uploaded_at':'2026-03-20T12:00:00Z'}
    brief = build_brief(sample, meta)
    print(brief['markdown'])
