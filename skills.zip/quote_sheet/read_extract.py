"""
Skill 2 — Read & Extract
Parses a quote sheet (PDF bytes) and returns structured extraction (versions A and B).
This is a scaffold/stub. Outputs follow the canonical extraction schema: each extraction contains a top-level
"fields" list where each element conforms to the canonical_extraction_schema.json.
Always returns candidate results and an action plan; does NOT write to memory without HITL Confirm.
"""

import json
from typing import Dict, Any, Tuple, List
from .presenter import build_brief
from .normalize import normalize_key_terms, detect_hidden_conditions_from_text

# helper: normalize numeric string to number when possible

def _to_number(v):
    try:
        return float(str(v).replace(',','').replace('$',''))
    except Exception:
        return None


def _make_bbox_placeholder():
    return {"x": 0, "y": 0, "width": 0, "height": 0, "coords_unit": "pixels"}


def _canonical_field(field_id: str, field_name: str, canonical_name: str, value: Any, unit: str, source_document_id: str, page: int, raw_text: str, confidence: float, extractor_version: str = "quote_sheet_v1.0.0") -> Dict[str, Any]:
    return {
        "field_id": field_id,
        "field_name": field_name,
        "canonical_name": canonical_name,
        "value": value,
        "unit": unit,
        "source_document_id": source_document_id,
        "page": page or 1,
        "bounding_box": _make_bbox_placeholder(),
        "extractor_version": extractor_version,
        "confidence": confidence if confidence is not None else 0.0,
        "raw_text": raw_text
    }


def extract_from_text(text: str, aggressive: bool = False, metadata: Dict[str, Any] = None) -> Dict[str, Any]:
    """Naive text-based extraction stub. In production, use OCR + layout parser + table extractor.
    Returns a canonical extraction: { "fields": [...], "meta": {...} }
    """
    metadata = metadata or {}
    source_id = metadata.get('quote_id') or metadata.get('source_document_id') or 'QUOTE-UNKNOWN'

    # Placeholder: create a few canonical fields based on mocked detection
    fields = []

    # Medical coverage limit
    fields.append(_canonical_field(
        field_id = f"coverage_limit:medical",
        field_name = "Medical coverage limit",
        canonical_name = "medical_coverage_limit",
        value = 1000000 if not aggressive else 800000,
        unit = "USD",
        source_document_id = source_id,
        page = 2,
        raw_text = "$1,000,000" if not aggressive else "$800,000",
        confidence = 0.98 if not aggressive else 0.9
    ))

    # Premium
    fields.append(_canonical_field(
        field_id = "premium:annual",
        field_name = "Annual premium",
        canonical_name = "annual_premium",
        value = 12000,
        unit = "USD",
        source_document_id = source_id,
        page = 2,
        raw_text = "12,000",
        confidence = 0.95
    ))

    # Key terms (copay)
    fields.append(_canonical_field(
        field_id = "copay",
        field_name = "Co-pay",
        canonical_name = "copay",
        value = "10%",
        unit = "%",
        source_document_id = source_id,
        page = 5,
        raw_text = "Co-pay 10%",
        confidence = 0.9
    ))

    # Hidden condition if aggressive
    if aggressive:
        fields.append(_canonical_field(
            field_id = "hidden:sub_limit",
            field_name = "Sub-limit hidden condition",
            canonical_name = "sub_limit_hidden",
            value = "100000",
            unit = "USD",
            source_document_id = source_id,
            page = 5,
            raw_text = "subject to sub-limit of $100,000",
            confidence = 0.86
        ))

    extraction = {
        "fields": fields,
        "meta": {
            "company_id": metadata.get('company_id'),
            "quote_id": metadata.get('quote_id'),
            "version": metadata.get('version') or ('B' if aggressive else 'A'),
            "uploaded_by": metadata.get('uploaded_by'),
            "uploaded_at": metadata.get('uploaded_at')
        }
    }

    return extraction


def read_and_extract(pdf_bytes: bytes, metadata: Dict[str, Any], version: str = 'A') -> Dict[str, Any]:
    """Main entry: return candidate extraction and brief. Does NOT write to memory.
    Returns: {extraction:..., brief: {markdown,json}, action_plan: [...]}
    """
    # In real implementation: run OCR if needed and pass text to extract_from_text
    # Placeholder: convert pdf_bytes to a dummy text
    text = "(extracted text placeholder)"
    aggressive = (version == 'B')
    extraction = extract_from_text(text, aggressive=aggressive, metadata=metadata)

    metadata_local = {"company_id": metadata.get('company_id'), "quote_id": metadata.get('quote_id'), "version": version, "uploaded_by": metadata.get('uploaded_by'), "uploaded_at": metadata.get('uploaded_at')}
    # Build brief from canonical extraction - presenter updated to understand canonical fields
    brief = build_brief(extraction, metadata_local)

    staging_extraction_path = f"INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_quotes/{metadata.get('company_id')}/{metadata.get('quote_id')}_extraction_v{version}.json"

    # Build a payment proposal line if premium info is present
    proposed_payment_line = None
    try:
        # look for annual_premium field
        pv = [f for f in extraction.get('fields', []) if f.get('canonical_name') == 'annual_premium']
        if pv and pv[0].get('value'):
            amt = pv[0].get('value')
            cur = pv[0].get('unit') or metadata.get('currency', 'USD')
            payee = metadata.get('proposed_payee', 'insurer')
            proposed_payment_line = f"Authorize payment of {amt} {cur} to {payee} (requires explicit 'Confirm Payment')"
    except Exception:
        proposed_payment_line = None

    action_plan = [
        f"Write staged extraction to {staging_extraction_path}",
        f"Present brief to human for HITL Confirm"
    ]
    if proposed_payment_line:
        action_plan.append(proposed_payment_line)

    return {"extraction": extraction, "brief": brief, "action_plan": action_plan}


if __name__ == '__main__':
    demo = read_and_extract(b"%PDF-example", {"company_id": "COMP-1234", "quote_id": "QUOTE-20260320-aaaa", "uploaded_by": "rahul.v", "uploaded_at": "2026-03-20T12:00:00Z"}, version='B')
    print(demo['brief']['markdown'])
