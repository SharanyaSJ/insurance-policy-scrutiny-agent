import unittest
from INSURANCE_POLICY_SCRUTINY_AGENT.skills.quote_sheet.normalize import normalize_term, normalize_key_terms, detect_hidden_conditions_from_text
from INSURANCE_POLICY_SCRUTINY_AGENT.skills.quote_sheet.compare import compare_fields

class TestNormalizeAndCompare(unittest.TestCase):
    def test_normalize_term(self):
        self.assertEqual(normalize_term('co-pay'), 'member_contribution')
        self.assertEqual(normalize_term('room charge'), 'room_rent')

    def test_detect_hidden(self):
        txt = 'Coverage is provided subject to sub-limit of $100,000 for inpatient.'
        snippets = detect_hidden_conditions_from_text(txt)
        self.assertTrue(len(snippets) >= 1)

    def test_compare_lower_limit(self):
        rfp = {'extraction': {'coverage_limits': [{'coverage_type':'Medical','limit':'1000000'}], 'premium_values':[{'amount':'12000'}], 'exclusions':[], 'hidden_conditions':[]}}
        quote = {'quote_id':'Q1','company_id':'COMP-1','extraction': {'coverage_summary':[{'coverage_type':'Medical','limit':'800000'}],'premium_values':[{'amount':'13000'}],'hidden_conditions':[]}}
        rep = compare_fields(rfp, quote, tolerance_percent=0.0)
        self.assertTrue(any(d['type']=='lower_limit_than_rfp' for d in rep['deviations']))

if __name__ == '__main__':
    unittest.main()
