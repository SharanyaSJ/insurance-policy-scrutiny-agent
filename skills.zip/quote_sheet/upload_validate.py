"""
Skill 1 — Upload & Validate
Checks whether a quote PDF is usable and returns Accept or Quarantine with reasons.
This is a stub implementation that performs basic checks and returns a candidate result.
"""

import os
from typing import Dict, Any, Tuple


def validate_pdf_bytes(pdf_bytes: bytes, metadata: Dict[str, Any], max_size_bytes: int=50_000_000) -> Tuple[bool, Dict[str, Any]]:
    """Return (accepted, details). If not accepted, details contains reason_code and message."""
    details = {"metadata": metadata}
    if not pdf_bytes:
        return False, {"reason_code": "empty_file", "message": "Uploaded file is empty."}
    if len(pdf_bytes) > max_size_bytes:
        return False, {"reason_code": "file_too_large", "message": f"File exceeds max size {max_size_bytes} bytes."}
    # naive check for PDF header
    if not pdf_bytes[:4] == b"%PDF":
        # could be scanned image in other container; attempt to accept if contains image markers — placeholder
        return False, {"reason_code": "invalid_pdf_header", "message": "File does not start with %PDF header."}
    # additional checks: password-protected detection, corrupt pdf detection would go here
    return True, {"reason_code": "accepted", "message": "File looks valid."}


def upload_and_validate(pdf_bytes: bytes, metadata: Dict[str, Any]) -> Dict[str, Any]:
    """Main entry: validate and return candidate action.
    Does NOT write files. Returns a dict with: {accepted: bool, details: {...}, action_plan: [...]}.
    """
    accepted, details = validate_pdf_bytes(pdf_bytes, metadata)
    if not accepted:
        # prepare quarantine action plan
        action_plan = [f"Quarantine to INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/{metadata.get('company_id')}/quotes/quarantine/{metadata.get('quote_id')}/"]
        return {"accepted": False, "details": details, "action_plan": action_plan}

    # if accepted, prepare staging paths (no writes performed)
    staging_pdf_path = f"INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_quotes/{metadata.get('company_id')}/{metadata.get('quote_id')}.pdf"
    staging_extraction_path_A = f"INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_quotes/{metadata.get('company_id')}/{metadata.get('quote_id')}_extraction_vA.json"
    staging_extraction_path_B = f"INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_quotes/{metadata.get('company_id')}/{metadata.get('quote_id')}_extraction_vB.json"
    action_plan = [
        f"Save staging PDF to {staging_pdf_path}",
        f"Run Read & Extract (vA) and write to {staging_extraction_path_A}",
        f"Run Read & Extract (vB) and write to {staging_extraction_path_B}"
    ]
    return {"accepted": True, "details": details, "action_plan": action_plan}


if __name__ == '__main__':
    # example usage
    print(upload_and_validate(b"%PDF-example", {"company_id":"COMP-1234","quote_id":"QUOTE-20260320-aaaa","uploaded_by":"rahul.v"}))
