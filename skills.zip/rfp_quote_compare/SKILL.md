---
name: rfp-quote-compare
description: "Clause mapping, validation, and risk detection for rigorous RFP vs Quote comparisons. Includes upstream/downstream notes and failure modes."
license: Proprietary
---

# RFP vs Quote Comparison Skillset

## Overview
Deterministic, auditable comparison of RFP baselines against insurer quotes using clause mapping, validation, and risk scoring.

## When to use
- When a quote extraction and RFP extraction are available and you need a comparison report for HITL review.

## Upstream / Downstream
- Upstream: pdf_rfp (RFP extraction), quote_sheet (quote extraction), memory (company config)
- Downstream: three_way_comparison (for combined policy checks), final_reporting, HITL (for writes)

## Core workflow
1) Clause mapping (clause_mapper) → mapping_table.json
2) Per-field validation (validation_engine) → validation flags
3) Risk scoring (risk_detector) → risk_score + recommendations
4) Produce comparison_report.json and present to HITL for Confirm before writes

## Outputs
- comparison_report.json (structured)
- human brief for HITL
- suggested memory writes (schema-validated) for case records
- FINAL compliance artifact (plain text/markdown) MUST follow the STRICT COMPLIANCE format template: INSURANCE_POLICY_SCRUTINY_AGENT/skills/utils/STRICT_COMPLIANCE_TEMPLATE.md

## Storage & Path Rules (MANDATORY)
- RFP extractions must be loaded from: data/companies/<COMPANY_ID>/rfps/
- Quote extractions must be loaded from: data/companies/<COMPANY_ID>/quotes/
- Comparison outputs and strict compliance artifacts MUST be written to: output/comparisons/<COMPANY_ID>/<CASE_ID>/strict_compliance_<QUOTE_ID>.md and comparison_report.json in the same folder.
- Do NOT write any artifacts outside the INSURANCE_POLICY_SCRUTINY_AGENT project folder. The orchestrator enforces this and will block/abort writes outside data/ or output/.

## Strict Compliance Requirements
- Every atomic failure MUST be output as a single row in the FLAG TABLE per CORE RULES.
- The tool MUST include Total Flags and Verdict in a SUMMARY section preceding the FLAG TABLE.
- No analyst narrative or grouped flags allowed in final comparison artifacts.

## Failure modes
- mapping_mismatch: fuzzy match produced incorrect mapping — detect via low mapping_confidence and mark for HITL
- validation_error: malformed values or types — produce structured errors and require remediation
- risk_weight_missing: missing company risk weights → fallback to default weights and flag for review
- evidence_link_missing: missing page/snippet evidence for mapping — mark as low-confidence
- persistence_failure: writing comparison artifacts fails — retry + alert and do not update memory

## QA & checks
- Validate comparison_report.json against mapping/comparison templates
- Require sample HITL review for mappings with confidence in (0.4, 0.75)

## Developer notes
- Keep risk_weights configurable per company under memory/companies/<COMPANY_ID>/config/risk_weights.json
