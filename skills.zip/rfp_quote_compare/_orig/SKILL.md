---
name: rfp-quote-compare
description: "Clause mapping, validation, and risk detection for rigorous RFP vs Quote comparisons."
license: Proprietary
---

# RFP vs Quote Comparison Skillset

## Overview
Clause mapping, validation, and risk detection for rigorous RFP vs Quote comparisons.

## When To Use
- When performing a comparison between an RFP baseline and an insurer quote
- When proposing memory writes related to comparison reports
- 
## Step by Step Process
1. title: "RFP vs Quote Comparison Skillset"
summary: "Clause mapping, validation, and risk detection for rigorous RFP vs Quote comparisons."
read_when:
  - When performing a comparison between an RFP baseline and an insurer quote
  - When proposing memory writes related to comparison reports
---

2. # RFP vs Quote Comparison — Skillset

3. Purpose
- Provide deterministic, auditable comparison of RFP baselines against insurer quotes using three core components:
  1) clause_mapper — align RFP clauses/fields with quote fields
  2) validation_engine — validate quote values against RFP rules
  3) risk_detector — score deviations and produce recommendations
- Produce a Comparison Report (Match / Deviation, Risk level, Recommendation) and present it to human reviewers for HITL confirmation before any memory write.

4. Core components
- clause_mapper: mapping logic with synonym & fuzzy matching, manual override hooks, and evidence linking (page/snippet). Produces a mapping table: [{rfp_field, quote_field, confidence, evidence}].
- validation_engine: runs rule checks (presence, type, numeric ranges, enumerations) and emits per-field results with error codes and messages.
- risk_detector: assigns severity weights to validation failures, aggregates a risk_score and maps to risk levels (Low/Medium/High/Critical), and generates remediation suggestions.

5. Outputs
- Comparison Report JSON (structured) and a human-readable markdown brief that includes:
  - TL;DR (Match/Deviation summary)
  - Field mapping table (key mappings + confidence)
  - Validation results per field
  - Deviations list with evidence snippets
  - Risk level and recommendation
  - Exact numbered action plan for HITL (store report, update case memory, escalate)

6. Safety & HITL
- All writes require explicit human Confirm via the HITL skill. The system will present a numbered action plan and await confirmation.
- All actions logged to audit.log with provenance, session_id, actor, and confidence.

7. Templates & tests
- Provide mapping/validation/risk config templates and unit tests for mapping, validation, and risk scoring.

8. Developer notes
- Implementations should support manual mapping overrides and an administrative mapping editor UI for repeated mapping patterns.
- Keep risk weights configurable per company in memory/companies/<COMPANY_ID>/config/risk_weights.json.


## Rules & Constraints
> Safety & HITL
> - All writes require explicit human Confirm via the HITL skill. The system will present a numbered action plan and await confirmation.
> - All actions logged to audit.log with provenance, session_id, actor, and confidence.
> 
> Templates & tests
> - Provide mapping/validation/risk config templates and unit tests for mapping, validation, and risk scoring.
> 
> Developer notes
> - Implementations should support manual mapping overrides and an administrative mapping editor UI for repeated mapping patterns.
> - Keep risk weights configurable per company in memory/companies/<COMPANY_ID>/config/risk_weights.json.

## Quick Reference
| Operation | Path / Note |
|---|---:|
| Primary files | see skill folder |