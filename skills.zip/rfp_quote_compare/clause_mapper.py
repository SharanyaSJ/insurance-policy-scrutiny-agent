"""
clause_mapper.py
Maps RFP canonical fields to Quote canonical fields using synonym and fuzzy matching heuristics.
Produces mapping table with confidence and evidence links. Expects inputs as lists of canonical field objects
(each following canonical_extraction_schema.json).
"""

from typing import Dict, Any, List, Tuple
import difflib

# Simple synonym map; extend per domain
SYNONYMS = {
    'co-pay': 'member contribution',
    'copay': 'member contribution',
    'deductible': 'deductible',
    'room rent': 'room_rent',
}


def normalize_label(s: str) -> str:
    return (s or "").strip().lower()


def synonym_equivalence(a: str, b: str) -> bool:
    return SYNONYMS.get(a) == b or SYNONYMS.get(b) == a


def fuzzy_score(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    a_n = normalize_label(a)
    b_n = normalize_label(b)
    # Use SequenceMatcher ratio as a simple fuzzy metric
    return difflib.SequenceMatcher(None, a_n, b_n).ratio()


def map_fields(rfp_fields: List[Dict[str, Any]], quote_fields: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Return list of mappings: {rfp_field_id, quote_field_id, confidence, evidence}
    rfp_fields and quote_fields are lists of canonical field dicts.
    """
    mappings = []
    for r in rfp_fields:
        best = None
        best_score = 0.0
        r_label = r.get('field_name') or r.get('canonical_name') or r.get('field_id')
        r_text = (r.get('raw_text') or '')
        for q in quote_fields:
            q_label = q.get('field_name') or q.get('canonical_name') or q.get('field_id')
            q_text = (q.get('raw_text') or '')
            score = 0.0
            if synonym_equivalence(r_label, q_label):
                score = 0.95
            else:
                score = fuzzy_score(r_label, q_label)
            # boost score if snippet evidence shares tokens
            if r_text and q_text:
                r_tokens = r_text.lower().split()[:4]
                if any(tok in q_text.lower() for tok in r_tokens):
                    score = max(score, 0.85)
            # boost if canonical_name matches exactly
            if r.get('canonical_name') and q.get('canonical_name') and r.get('canonical_name') == q.get('canonical_name'):
                score = max(score, 0.99)
            if score > best_score:
                best_score = score
                best = q
        mapping = {
            'rfp_field_id': r.get('field_id'),
            'rfp_field_name': r_label,
            'quote_field_id': best.get('field_id') if best else None,
            'quote_field_name': best.get('field_name') if best else None,
            'confidence': round(best_score, 2),
            'evidence': {
                'rfp_raw_text': r_text,
                'rfp_page': r.get('page'),
                'rfp_confidence': r.get('confidence'),
                'quote_raw_text': best.get('raw_text') if best else None,
                'quote_page': best.get('page') if best else None,
                'quote_confidence': best.get('confidence') if best else None
            }
        }
        mappings.append(mapping)
    return mappings


if __name__ == '__main__':
    # simple demo using canonical field shapes
    rfp_fields = [{'field_id':'f1','field_name':'Co-Pay','canonical_name':'copay','raw_text':'Co-pay 10% for OPD','page':3,'confidence':0.92}, {'field_id':'f2','field_name':'Medical Limit','canonical_name':'medical_coverage_limit','raw_text':'Limit $1,000,000','page':2,'confidence':0.95}]
    quote_fields = [{'field_id':'q1','field_name':'member contribution','canonical_name':'copay','raw_text':'Member contributes 10%','page':5,'confidence':0.9}, {'field_id':'q2','field_name':'Coverage Limit','canonical_name':'medical_coverage_limit','raw_text':'Coverage limit $1,000,000','page':1,'confidence':0.88}]
    print(map_fields(rfp_fields, quote_fields))
