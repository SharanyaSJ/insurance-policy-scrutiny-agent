"""
Top-level compare for rfp_quote_compare skill.
Takes canonical rfp_extraction and quote_extraction (each an object with 'fields' list).
Produces mapping table where each mapped field carries source confidences and a 'requires_human_review' flag if any source confidence < 0.75.
Also runs validation_engine.run_validations and returns a structured report.
"""
from typing import Dict, Any, List, Tuple
from .clause_mapper import map_fields
from .validation_engine import run_validations
from .presenter import build_comparison_report

LOW_CONFIDENCE_THRESHOLD = 0.75


def compare_fields(rfp: Dict[str,Any], quote: Dict[str,Any], tolerance_percent: float=0.0) -> Dict[str,Any]:
    """Run mapping and validation and return comparison report.
    Inputs:
      rfp: {'extraction': {'fields': [...]}, ...}
      quote: {'extraction': {'fields': [...]}, ...}
    """
    rfp_fields = rfp.get('extraction', {}).get('fields', []) if rfp.get('extraction') else []
    quote_fields = quote.get('extraction', {}).get('fields', []) if quote.get('extraction') else []

    # 1) Map fields
    mappings = map_fields(rfp_fields, quote_fields)

    # 2) Enrich mapping with confidence propagation and low-confidence flags
    for m in mappings:
        r_conf = m.get('evidence', {}).get('rfp_confidence')
        q_conf = m.get('evidence', {}).get('quote_confidence')
        m['rfp_confidence'] = r_conf
        m['quote_confidence'] = q_conf
        m['mapped_confidence'] = None
        # compute a combined mapping confidence that respects both mapping score and source confidences
        try:
            scores = [val for val in [m.get('confidence') or 0.0, r_conf or 0.0, q_conf or 0.0] if isinstance(val, (int,float))]
            if scores:
                m['mapped_confidence'] = round(sum(scores)/len(scores), 3)
        except Exception:
            m['mapped_confidence'] = m.get('confidence')
        # flag for HITL if either source confidence below threshold
        m['requires_human_review'] = False
        if (r_conf is not None and r_conf < LOW_CONFIDENCE_THRESHOLD) or (q_conf is not None and q_conf < LOW_CONFIDENCE_THRESHOLD):
            m['requires_human_review'] = True

    # 3) Run validations
    validation_results = run_validations(mappings, rfp.get('extraction', {}), quote.get('extraction', {}), tolerance_percent)

    # 4) Build deviations list from validation failures
    deviations = []
    for vr in validation_results:
        for chk in vr.get('checks', []):
            if chk.get('check') == 'presence' and not chk.get('pass'):
                deviations.append({'type':'missing_in_quote','rfp_field_id': vr.get('rfp_field_id'),'reason': chk.get('reason')})
            if chk.get('check') == 'numeric_range' and not chk.get('pass'):
                deviations.append({'type':'numeric_deviation','rfp_field_id': vr.get('rfp_field_id'),'reason': chk.get('reason'),'rfp_val': chk.get('rfp_val'),'quote_val': chk.get('quote_val')})

    # 5) Simple risk summary
    risk_score = min(1.0, 0.1 * len(deviations))
    risk_summary = {'risk_score': risk_score, 'risk_level': 'High' if risk_score>0.5 else 'Medium' if risk_score>0.2 else 'Low', 'recommendations': []}

    report = {
        'meta': {'company_id': quote.get('company_id'), 'quote_id': quote.get('quote_id')},
        'mapping': mappings,
        'validation': validation_results,
        'deviations': deviations,
        'risk': risk_summary
    }

    # 6) If any mapping requires human review, include an explicit flag
    report['requires_human_review'] = any([m.get('requires_human_review') for m in mappings])

    return report


if __name__ == '__main__':
    # demo
    rfp = {'extraction': {'fields': [{'field_id':'f1','field_name':'Medical Limit','canonical_name':'medical_coverage_limit','value':1000000,'confidence':0.9}]}}
    quote = {'company_id':'COMP-1','quote_id':'Q1','extraction': {'fields': [{'field_id':'q1','field_name':'Coverage Limit','canonical_name':'medical_coverage_limit','value':800000,'confidence':0.7}]}}
    out = compare_fields(rfp, quote)
    from pprint import pprint
    pprint(out)
