---
# Presenter for RFP vs Quote Comparison
# Builds the human-readable Comparison Report and structured JSON output
---

import json
from datetime import datetime
from typing import Dict, Any, List


def build_comparison_report(mapping: List[Dict[str,Any]], validation_results: List[Dict[str,Any]], deviations: List[Dict[str,Any]], risk_summary: Dict[str,Any], metadata: Dict[str,Any]) -> Dict[str,Any]:
    report = {
        'meta': metadata,
        'mapping': mapping,
        'validation': validation_results,
        'deviations': deviations,
        'risk': risk_summary,
        'generated_at': datetime.utcnow().isoformat() + 'Z'
    }
    # Markdown brief
    md = []
    md.append(f"TL;DR: {len(deviations)} deviations detected — risk: {risk_summary.get('risk_level')} (score {risk_summary.get('risk_score'):.2f})")
    md.append("")
    md.append("Field mappings (rfp -> quote, confidence):")
    for m in mapping:
        md.append(f"- {m.get('rfp_field')} -> {m.get('quote_field')} (conf {m.get('confidence')})")
    md.append("")
    md.append("Validation results:")
    for v in validation_results:
        md.append(f"- {v.get('rfp_field')}: {', '.join([f\"{c['check']}={'PASS' if c['pass'] else 'FAIL'}({c['reason']})\" for c in v.get('checks',[])])}")
    md.append("")
    md.append("Deviations:")
    for d in deviations[:20]:
        md.append(f"- {d}")
    md.append("")
    md.append("Risk & Recommendations:")
    md.append(f"- Level: {risk_summary.get('risk_level')}")
    md.append(f"- Score: {risk_summary.get('risk_score'):.2f}")
    for r in risk_summary.get('recommendations',[]):
        md.append(f"- Recommendation: {r}")
    md.append("")
    md.append("Code / Paths:")
    md.append("```")
    md.append(f"INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/{metadata.get('company_id')}/comparisons/")
    md.append("```")
    md.append("")

    # Build explicit action plan. If a proposed payment is present in metadata, include a payment authorization step
    action_lines = []
    action_lines.append("1) Save Comparison Report to INSURANCE_POLICY_SCRUTINY_AGENT/memory/companies/{company_id}/comparisons/".format(company_id=metadata.get('company_id')))
    action_lines.append("2) Update case memory and link comparison to case")
    if metadata.get('proposed_payment'):
        pp = metadata.get('proposed_payment')
        amt = pp.get('amount')
        cur = pp.get('currency','USD')
        payee = pp.get('payee','insurer')
        action_lines.append(f"3) Authorize payment of {amt} {cur} to {payee} (requires explicit 'Confirm Payment')")

    md.append("Action plan (numbered):")
    for l in action_lines:
        md.append(f"- {l}")

    md.append("")
    md.append("Provide an explicit Confirm (e.g. 'Confirm' or 'Confirm 1 and 2') to proceed with writes. For payments, respond with 'Confirm Payment' or 'Confirm 3' to authorize the payment step.")

    return {'markdown': '\n'.join(md), 'json': report}


if __name__=='__main__':
    # demo
    mapping = [{'rfp_field':'Co-Pay','quote_field':'member contribution','confidence':0.9}]
    validation = [{'rfp_field':'Co-Pay','quote_field':'member contribution','confidence':0.9,'checks':[{'check':'presence','pass':True,'reason':'present'}]}]
    deviations = [{'type':'lower_limit_than_rfp','coverage_type':'Medical','rfp_limit':'1000000','quote_limit':'800000'}]
    risk = {'risk_score':0.3,'risk_level':'Medium','recommendations':['Request higher limits.']}
    meta = {'company_id':'COMP-1234','rfp_id':'RFP-20260320-a1b2','quote_id':'QUOTE-20260321-bbbb'}
    out = build_comparison_report(mapping, validation, deviations, risk, meta)
    print(out['markdown'])
