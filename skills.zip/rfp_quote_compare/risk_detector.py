"""
risk_detector.py
Aggregates validation results into a risk score and produces recommendations.
"""

from typing import Dict, Any, List

# default weights (can be overridden per company)
DEFAULT_WEIGHTS = {
    'missing_clause': 0.4,
    'value_lower_than_rfp': 0.3,
    'new_condition': 0.25,
    'premium_higher_than_expected': 0.2,
    'hidden_condition': 0.25,
    'not_numeric': 0.1,
}


def aggregate_risk(validation_results: List[Dict[str,Any]], deviations: List[Dict[str,Any]], weights: Dict[str,float]=None) -> Dict[str,Any]:
    if weights is None:
        weights = DEFAULT_WEIGHTS
    score = 0.0
    details = []
    for v in validation_results:
        for check in v.get('checks', []):
            if not check.get('pass'):
                reason = check.get('reason')
                # map reason to weight
                w = weights.get(reason, 0.05)
                score += w
                details.append({'field': v.get('rfp_field'), 'check': check.get('check'), 'reason': reason, 'weight': w})
    for d in deviations:
        dtype = d.get('type')
        w = weights.get(dtype, 0.1)
        score += w
        details.append({'deviation': dtype, **{k:v for k,v in d.items() if k!='type'}, 'weight': w})
    # normalize
    risk_score = min(1.0, score)
    # map to level
    if risk_score >= 0.7:
        level = 'Critical'
    elif risk_score >= 0.4:
        level = 'High'
    elif risk_score >= 0.15:
        level = 'Medium'
    else:
        level = 'Low'

    # recommendations simple rule-based
    recs = []
    if level in ('Critical','High'):
        recs.append('Reject quote or renegotiate key terms: coverage limits and hidden conditions.')
    if any(d.get('type')=='new_condition' for d in deviations):
        recs.append('Escalate to legal to review new conditions.')
    if any(check.get('reason')=='value_lower_than_rfp' for v in validation_results for check in v.get('checks', [])):
        recs.append('Request higher limits or adjust premium accordingly.')

    return {'risk_score': risk_score, 'risk_level': level, 'details': details, 'recommendations': recs}


if __name__=='__main__':
    print(aggregate_risk([], [{'type':'new_condition','snippet':'...'}]))
