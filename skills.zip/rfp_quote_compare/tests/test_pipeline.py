import unittest
from INSURANCE_POLICY_SCRUTINY_AGENT.skills.rfp_quote_compare.clause_mapper import map_fields
from INSURANCE_POLICY_SCRUTINY_AGENT.skills.rfp_quote_compare.validation_engine import run_validations
from INSURANCE_POLICY_SCRUTINY_AGENT.skills.rfp_quote_compare.risk_detector import aggregate_risk

class TestRPFPipeline(unittest.TestCase):
    def test_mapping_and_validation_and_risk(self):
        rfp_fields = [{'name':'Co-Pay','sample_text':'Co-pay 10% for OPD','page':3,'value':None}, {'name':'Medical Limit','sample_text':'Limit $1,000,000','page':2,'value':'1000000'}]
        quote_fields = [{'name':'member contribution','sample_text':'Member contributes 10%','page':5},{'name':'Coverage Limit','sample_text':'Coverage limit $800,000','page':1}]
        mapping = map_fields(rfp_fields, quote_fields)
        rfp_extraction = {'fields': rfp_fields}
        quote_extraction = {'coverage_summary': [{'coverage_type':'Coverage Limit','limit':'800000'}], 'premium_values': []}
        validation = run_validations(mapping, rfp_extraction, quote_extraction)
        deviations = [{'type':'lower_limit_than_rfp','coverage_type':'Medical','rfp_limit':'1000000','quote_limit':'800000'}]
        risk = aggregate_risk(validation, deviations)
        self.assertIn('risk_level', risk)

if __name__ == '__main__':
    unittest.main()
