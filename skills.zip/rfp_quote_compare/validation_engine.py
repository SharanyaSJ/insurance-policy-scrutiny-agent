"""
validation_engine.py
Validates quote fields against RFP requirements using rules. Emits per-field pass/fail and error codes.
Works with canonical extraction outputs: extraction objects contain 'fields' lists of canonical field dicts.
"""

from typing import Dict, Any, List, Tuple


def _to_number(v):
    try:
        return float(str(v).replace(',','').replace('$',''))
    except Exception:
        return None


def validate_presence(mapped: Dict[str,Any], quote_extraction: Dict[str,Any]) -> Tuple[bool,str]:
    q_field_id = mapped.get('quote_field_id')
    if not q_field_id:
        return False, 'mapped_field_missing'
    # check in quote_extraction fields
    exists = False
    for item in quote_extraction.get('fields', []):
        if item.get('field_id') == q_field_id or (mapped.get('quote_field_name') and (mapped.get('quote_field_name').lower() in (item.get('field_name') or '').lower() or mapped.get('quote_field_name').lower() in (item.get('canonical_name') or '').lower())):
            exists = True
            break
    return (exists, 'present' if exists else 'missing')


def validate_numeric_range(mapped: Dict[str,Any], rfp_value: Any, quote_value: Any, tolerance_percent: float=0.0) -> Tuple[bool,str]:
    rnum = _to_number(rfp_value)
    qnum = _to_number(quote_value)
    if rnum is None or qnum is None:
        return (False, 'not_numeric')
    allowed = rnum * (1.0 - tolerance_percent)
    if qnum < allowed:
        return (False, 'value_lower_than_rfp')
    return (True, 'within_range')


def validate_enumeration(mapped: Dict[str,Any], rfp_allowed: List[str], quote_val: str) -> Tuple[bool,str]:
    if not quote_val:
        return False, 'quote_empty'
    if quote_val.lower() in [a.lower() for a in rfp_allowed]:
        return True, 'allowed'
    return False, 'not_in_allowed_set'


def run_validations(mapping_table: List[Dict[str,Any]], rfp_extraction: Dict[str,Any], quote_extraction: Dict[str,Any], tolerance_percent: float=0.0) -> List[Dict[str,Any]]:
    """Run validations for each mapping entry and return results per field.
    Expects rfp_extraction and quote_extraction to expose 'fields' lists of canonical field dicts.
    """
    results = []
    # create quick lookup for rfp by field id
    rfp_lookup = { r.get('field_id'): r for r in rfp_extraction.get('fields', []) }

    # create quick lookup for quote by field id
    quote_lookup = { q.get('field_id'): q for q in quote_extraction.get('fields', []) }

    for m in mapping_table:
        rfp_field_id = m.get('rfp_field_id')
        q_field_id = m.get('quote_field_id')
        res = {'rfp_field_id': rfp_field_id, 'quote_field_id': q_field_id, 'mapping_confidence': m.get('confidence'), 'checks': []}

        # Presence check
        present, reason = validate_presence(m, quote_extraction)
        res['checks'].append({'check':'presence','pass':present,'reason':reason})

        # Numeric range check if both values exist and mapping is high-confidence
        rfp_val = None
        quote_val = None
        if rfp_field_id and rfp_lookup.get(rfp_field_id):
            rfp_val = rfp_lookup.get(rfp_field_id).get('value')
        if q_field_id and quote_lookup.get(q_field_id):
            quote_val = quote_lookup.get(q_field_id).get('value')

        # If mapping explicitly requests human review (low-confidence), skip numeric checks and add a skipped check entry
        if m.get('requires_human_review'):
            res['checks'].append({'check':'numeric_range','pass':False,'reason':'skipped_low_confidence','rfp_val': rfp_val,'quote_val': quote_val})
        else:
            if rfp_val is not None and quote_val is not None:
                ok, reason = validate_numeric_range(m, rfp_val, quote_val, tolerance_percent)
                res['checks'].append({'check':'numeric_range','pass':ok,'reason':reason,'rfp_val':rfp_val,'quote_val':quote_val})

        results.append(res)
    return results


if __name__=='__main__':
    # demo
    mapping = [{'rfp_field_id':'f1','quote_field_id':'q1','confidence':0.9}]
    rfp = {'fields':[{'field_id':'f1','value':'1000000'}]}
    quote = {'fields':[{'field_id':'q1','value':'800000'}]}
    print(run_validations(mapping, rfp, quote))
