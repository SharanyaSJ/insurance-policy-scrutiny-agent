---
name: three-way-comparison
description: "Compare RFP, Quote, and Issued Policy to produce a Final Compliance Matrix and detect deviations, drift, and compound mismatches across stages."
license: Proprietary
---

# Three‑Way Comparison Skill (RFP ↔ Quote ↔ Policy)

## Overview
This orchestration skill aligns clause- and field-level data from three artifacts — the RFP, the insurer Quote, and the Issued Policy — then validates, scores, and surfaces deviations. Primary deliverables are: mapping_table.json, drift_report.json, and compliance_matrix.json.

## When to use
- After structured extractions exist for RFP, Quote, and Policy (staged or canonical).
- When you need an auditable verdict of compliance or a prioritized list of deviations for remediation.

## Inputs (Upstream)
- RFP extraction JSON (rfp_extraction.json) — path or in-memory object
- Quote extraction JSON (quote_extraction.json)
- Canonical policy JSON (policy_structured.json)
- Company-level comparison config (memory/companies/<COMPANY_ID>/config/comparison.json)

## Outputs (Downstream)
- mapping_table.json — canonical alignment rows for each comparable field
- validation artifacts (normalized_value objects + flags)
- drift_report.json — drift and cumulative-change diagnostics
- compliance_matrix.json — final PASS/FAIL/REQUIRES_REVIEW per field
- FINAL strict compliance artifact (plain markdown) MUST follow the project template: INSURANCE_POLICY_SCRUTINY_AGENT/skills/utils/STRICT_COMPLIANCE_TEMPLATE.md
- These outputs feed: final_reporting, HITL tasks, memory/cases for audit, and dashboarding services.

## Storage & Path Rules (MANDATORY)
- Input artifacts MUST be read from the project's data/ folder only (e.g., data/companies/<COMPANY_ID>/rfps/, data/companies/<COMPANY_ID>/quotes/, data/companies/<COMPANY_ID>/policies/).
- All outputs (mapping_table.json, drift_report.json, compliance_matrix.json, strict compliance artifacts) MUST be written to output/comparisons/<COMPANY_ID>/<CASE_ID>/ or other approved outputs subfolders under output/.
- DO NOT write any artifacts outside the INSURANCE_POLICY_SCRUTINY_AGENT project folder. The orchestrator will block any write target outside data/ or output/ and abort the run.
- Evidence links and page/snippet references must be stored in comparison_report.json inside the same outputs folder; do not place evidence links inside the strict compliance artifact.

## Step‑by‑step workflow
1) Load artifacts and config
   - Load RFP, Quote, Policy JSONs and company comparison config (tolerances, critical fields, risk weights).
2) Field alignment (multi_source_mapper)
   - Produce mapping_table rows: { field_id, rfp_path, quote_path, policy_path, mapping_confidence, canonical_type }
   - Example mapping row:
     {
       "field_id": "limits.general_liability",
       "rfp_path": "$.coverages.general_liability.limit",
       "quote_path": "$.coverages.GL.limit",
       "policy_path": "$.sections.coverages.general_liability.limit",
       "mapping_confidence": 0.92
     }
3) Per-field normalization & validation (validation_engine)
   - For each mapping row, extract values, normalize units/currency, coerce types, run validation rules (presence, ranges, enum membership), emit normalized_value and validation_flags.
   - Example normalized_value: {"value": 1000000, "units": "USD", "normalized": 1000000}
4) Drift detection (drift_detector)
   - Compute pairwise deltas (RFP↔Quote, Quote↔Policy) and pipeline drift (RFP→Quote→Policy). Detect compound mismatches (e.g., small pairwise deltas that accumulate into a material change).
   - Produce drift score per-field and severity level.
5) Final matrix assembly
   - Combine mapping, normalized values, validation flags, drift flags into compliance_matrix rows: { field_id, rfp_value, quote_value, policy_value, final_status, evidence }.
   - Apply company pass/fail rules to set final_status.
6) Persist artifacts
   - Write mapping_table.json, drift_report.json, compliance_matrix.json to the policy comparison folder and append audit entries.
   - Generate FINAL strict compliance artifact (SUMMARY + FLAG TABLE) strictly following INSURANCE_POLICY_SCRUTINY_AGENT/skills/utils/STRICT_COMPLIANCE_TEMPLATE.md and save as strict_compliance_three_way_<CASE_ID>.md in output/comparisons/<COMPANY_ID>/<case>/.
   - Do NOT include analyst narrative or evidence links in the strict compliance artifact. Evidence and page/snippet links must be stored in comparison_report.json only.
   - Do NOT write to company memory without HITL Confirm if required by config.
7) Present for HITL (if required)
   - Create a HITL task with TL;DR, top critical fails, and the exact numbered action plan for downstream writes.

## Example outputs (paths)
- INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/<COMPANY_ID>/policies/<POLICY_ID>/comparison/mapping_table.json
- .../comparison/drift_report.json
- .../comparison/compliance_matrix.json

## Mapping examples
- Simple numeric mapping: limits.general_liability → extract numeric USD and compare with tolerance
- Enumerated mapping: territory (RFP: "US & Canada") ↔ policy territory canonicalized to one of ["US", "Canada", "Worldwide"]
- Table mapping: schedule rows → map per-row fields (item, limit, deductible)

## Failure modes (per-field and systemic)
- Missing source: one or more upstream artifacts absent → fail fast and create a pre-check report (mark REQUIRES_REVIEW)
- Low mapping confidence: mapping_confidence < configured threshold → flag mapping uncertain and require HITL
- Normalization errors: incompatible units, ambiguous currency → include in drift report and mark REQUIRES_REVIEW
- Validation contradictions: RFP requires X but policy explicitly excludes X → mark FAIL and escalate
- Silent drift: small changes across each stage that sum to a material difference — detector should surface with compound_mismatch flag
- IO/write failures: persistence errors must be retried and logged; if persistent, raise alert and mark outputs as incomplete

## Upstream / Downstream (summary)
- Upstream: pdf_rfp (RFP extraction), quote_sheet (quote extraction), policy_document_ingestion (policy canonical JSON), memory (company config)
- Downstream: final_reporting, HITL (for required reviews), memory/cases (audit records), dashboards and downstream consumers

## QA & checks
- Schema validation for mapping_table.json, drift_report.json, compliance_matrix.json (use provided schemas in skills/memory/schemas)
- Smoke test: run on a known-good sample set and assert expected pass_rate and no unexpected REQUIRES_REVIEW rows
- Sampling: random sample of 5% of comparisons should be HITL-reviewed to ensure mapping drift not introduced

## Memory usage
- Store comparison metadata (who ran it, when, artifacts paths, final verdict) to case memory and audit.log. Use mapping_table and compliance_matrix hashes for provenance.

## Implementer notes
- Keep heavy compute in sub-skills (mapper/validator/drift_detector). This SKILL owns orchestration, artifact names, and gating logic.
- Configurable thresholds must live in memory/companies/<COMPANY_ID>/config/comparison.json to allow per-company tuning.

