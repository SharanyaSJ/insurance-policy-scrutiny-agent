---
name: three-way-comparison
description: "Compare RFP, Quote, and Issued Policy to produce a Final Compliance Matrix and detect deviations, drift, and compound mismatches across stages."
license: Proprietary
---

# ThreeWay Comparison Skill (RFP <-> Quote <-> Policy)

## Overview
This skill performs a structured, clause- and field-level comparison across three sources  RFP (request for proposal), insurer Quote, and the final Issued Policy  and produces a Final Compliance Matrix plus diagnostics for deviations, drift, and compound mismatches.

## When To Use
- After a Quote has been generated for a given RFP and an Issued Policy has been received.
- When assessing compliance and traceability from requirement (RFP)  offer (Quote)  final (Policy).
- Do NOT use on single-document checks; use only when all three sources are available or staged.

## Step by Step Process
1. Stage inputs
   - Ensure structured extractions exist for: RFP, Quote, and Policy (paths or in-memory objects). If any source is raw, call the document extraction pipeline first.
   - Example file locations:
   ```
   INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_briefs/<RFP_ID>_extraction.json
   INSURANCE_POLICY_SCRUTINY_AGENT/output/pending_quotes/<QUOTE_ID>_extraction.json
   INSURANCE_POLICY_SCRUTINY_AGENT/skills/policy_document_ingestion/final/<POLICY_ID>_structured.json
   ```
2. Map comparable fields (multi_source_mapper)
   - Invoke multi_source_mapper to align RFP fields to Quote fields and Policy fields producing a canonical mapping table: [{field_id, rfp_path, quote_path, policy_path, mapping_confidence}].
3. Validate values per mapped field (validation_engine)
   - For each mapped row, call validation_engine to extract values from each source and produce normalized_value objects and basic validations (type, range, presence).
4. Detect drift and compound mismatches (drift_detector)
   - Run drift_detector to compute: direct deviations (RFP vs Quote, Quote vs Policy), drift across pipeline (RFPQuotePolicy), and compound mismatches (cumulative changes that result in non-equivalence even if pairwise checks pass).
5. Assemble Final Compliance Matrix
   - Build matrix rows with: field_id, rfp_value, quote_value, policy_value, normalized_values, per-source confidence, validation_flags, drift_flags, final_status (PASS/FAIL/REQUIRES_REVIEW).
6. Produce diagnostics and artifacts
   - Save artifacts under policy archive:
   ```
   INSURANCE_POLICY_SCRUTINY_AGENT/data/companies/<COMPANY_ID>/policies/<POLICY_ID>/comparison/
     compliance_matrix.json
     mapping_table.json
     drift_report.json
   ```
7. Present results for HITL review and optionally persist final verdict to memory per HITL rules.

## Rules & Constraints
- Do not alter source files during comparison. Only write derived artifacts to the comparison folder.
- Use mapping confidence thresholds (configurable). If mapping_confidence < threshold, mark mapping as "uncertain" and include in drift hints.
- Final status rules:
  - PASS: All critical fields comply (exact match or acceptable normalized match) and no critical drift detected.
  - FAIL: Any critical field exhibits an unacceptable deviation in the final policy.
  - REQUIRES_REVIEW: Low-confidence mappings, conflicting evidence, or compound mismatch detected.
- Treat numeric tolerances and date windows as configuration parameters per company (memory/companies/<COMPANY_ID>/config/comparison.json).

## Quick Reference
| Operation | API / Path | Output |
|---|---|---:|
| Map fields | multi_source_mapper.map(rfp, quote, policy, config) | mapping_table.json |
| Validate values | validation_engine.validate(mapped_row) | normalized_value + flags |
| Detect drift | drift_detector.detect(mapped_rows) | drift_report.json |
| Final matrix | assemble_matrix(mapped_rows, validations, drifts) | compliance_matrix.json |


---

Implementation note: This skill delegates core work to sub-skills (multi_source_mapper, validation_engine, drift_detector). Do not embed heavy algorithms here; keep orchestration, artifact paths, and final assembly only.
