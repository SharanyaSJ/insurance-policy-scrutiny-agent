---
name: drift-detector
description: "Detect drift and compound mismatches across RFP → Quote → Policy for mapped fields; score and classify types of drift."
license: Proprietary
---

# Drift Detector (interface)

## Overview
The drift_detector examines validated mapped rows to identify direct deviations (RFP vs Quote, Quote vs Policy), staged drift across the pipeline, and compound mismatches where sequential benign changes produce an unacceptable final outcome.

## When To Use
- After validation_engine has normalized values for mapped fields.
- Whenever a new policy or addendum is issued and comparisons must be re-run.

## Step by Step Process
1. Input contract
   - Input: validated_rows (list) where each contains normalized_values and validation_flags.
2. Pairwise deviation checks
   - Compute dev_rq = compare(rfp_value, quote_value), dev_qp = compare(quote_value, policy_value) with metrics: exact_match, normalized_match, delta, percent_change.
3. Pipeline drift analysis
   - Evaluate RFP→Policy effect: if dev_rq + dev_qp cumulatively alter the requirement beyond tolerance, flag as pipeline_drift.
4. Compound mismatch detection
   - Identify cases where RFP→Quote change is non-critical but Quote→Policy change compounds to a critical failure (e.g., two partial limit reductions that sum to a critical shortfall).
5. Scoring & classification
   - Assign drift_type: {NO_DRIFT, MINOR, MAJOR, CRITICAL, COMPOUND_MISMATCH} and drift_score (0–1) per field.
6. Output
   - Return drift_report: list of {field_id, dev_rq, dev_qp, pipeline_drift_flag, drift_type, drift_score, notes} and summary counts.

## Rules & Constraints
- Use configured tolerances for numeric/date comparisons. Do not hardcode tolerances.
- Treat high-confidence discrepancies as higher priority even if numerically small.
- If validation_flags indicate low_confidence for any source, include that in scoring adjustments.

## Quick Reference
| Function | Signature | Output |
|---|---:|---|
| detect | detect(validated_rows, config) | drift_report, summary |
| compare | compare(a,b,config) | {match_type, delta, pct_change} |


