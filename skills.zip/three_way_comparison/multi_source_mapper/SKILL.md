---
name: multi-source-mapper
description: "Align fields and clause-level objects across three sources (RFP, Quote, Policy). Returns a canonical mapping table with confidence scores."
license: Proprietary
---

# Multi‑Source Mapper (interface)

## Overview
The multi_source_mapper aligns comparable fields, clause identifiers, and headings across RFP, Quote, and Policy extractions to produce a mapping table that downstream components use for validation and drift detection.

## When To Use
- As the first step in three-way comparisons when structured extractions for RFP, Quote, and Policy are available.
- Use also when a new addendum or amended policy is introduced to re-run alignments.

## Step by Step Process
1. Input contract
   - Accepts structured_extraction objects for rfp, quote, policy and optional config {similarity_threshold, heuristics}.
2. Header & clause normalization
   - Normalize headings and clause numbers (strip punctuation, unify whitespace, lowercase). Produce candidate keys.
3. Candidate matching
   - Use clause number first (if present) to align. Fall back to header similarity (token overlap, fuzzy match) and semantic similarity (embedding cosine) for unmatched items.
4. Multi-source consolidation
   - For each canonical key, produce mapping entry:
   ```json
   { "field_id": "string", "rfp_path": "jsonpath", "quote_path": "jsonpath|null", "policy_path": "jsonpath|null", "mapping_confidence": 0.0 }
   ```
5. Output
   - Return mapping_table (list) and a small summary: {matched, unmatched_rfp, unmatched_quote, unmatched_policy, avg_confidence}.

## Rules & Constraints
- Respect existing clause identifiers when present; numeric ids take precedence over fuzzy matching.
- Never fabricate a mapping entry without a confidence score; use 0.0–1.0.
- If mapping_confidence < config.min_confidence, mark entry as "uncertain" and include candidate alternatives in the mapping_table entry.

## Quick Reference
| Function | Signature | Description |
|---|---:|---|
| map | map(rfp, quote, policy, config) | returns (mapping_table, summary) |
| normalize | normalize_heading(text) | returns canonical heading string |


