---
name: validation-engine
description: "Validate and normalize mapped field values from RFP, Quote, and Policy; perform type, range, and presence checks and emit per-field flags."
license: Proprietary
---

# Validation Engine (interface)

## Overview
The validation_engine takes a mapped field (output of multi_source_mapper) and extracts/normalizes values from each source, applying schema rules, numeric tolerances, enumerations, and date checks. It returns normalized values and validation flags.

## When To Use
- After mapping table generation and before drift detection or matrix assembly.
- When validating new or updated mappings (e.g., after manual mapping override).

## Step by Step Process
1. Input contract
   - Input: mapped_row {field_id, rfp_path, quote_path, policy_path, mapping_confidence}, plus source_extractions and config (tolerances, enumerations).
2. Extract values
   - Use provided jsonpaths to pull raw values; capture source confidence and location (file, page, span).
3. Normalize
   - Apply normalization rules by type: numeric (parse, round), currency (strip symbols), dates (parse to ISO), enumerations (canonical mapping), booleans.
4. Validate
   - Type check, presence check, range check (min/max/tolerance), enumeration membership.
   - Produce validation_flags: {missing, type_mismatch, out_of_range, enum_mismatch, low_confidence}
5. Output
   - Return: {field_id, rfp_value, quote_value, policy_value, normalized_values, validation_flags, per_source_confidence}

## Rules & Constraints
- Use company-specific config when available (memory/companies/<COMPANY_ID>/config/comparison.json). Fallback to global defaults.
- Do not coerce values silently; when coercion occurs, record the original raw_value and the coercion performed.
- Keep per-source confidence and provenance with every returned value.

## Quick Reference
| Function | Signature | Output |
|---|---:|---|
| validate | validate(mapped_row, sources, config) | normalized_values + flags |
| normalize_value | normalize_value(raw, type) | normalized value + notes |


