"""
Retry utility with exponential backoff.
Provides a decorator `retry` and a function `retry_call` to wrap callables that may fail transiently.
Configuration options: attempts, backoff_factor (seconds), max_delay, exceptions to catch, jitter.

Usage:
@retry(attempts=3, backoff_factor=2)
def fragile_call(...):
    ...

Or:
result = retry_call(fragile_call, attempts=3, backoff_factor=2, arg1, kw=val)
"""
import time
import random
import functools
import logging

logger = logging.getLogger(__name__)

DEFAULT_ATTEMPTS = 3
DEFAULT_BACKOFF = 1.0
DEFAULT_MAX_DELAY = 30.0


def retry(attempts=DEFAULT_ATTEMPTS, backoff_factor=DEFAULT_BACKOFF, max_delay=DEFAULT_MAX_DELAY, exceptions=(Exception,), jitter=True):
    """Decorator to retry a function on exception.

    attempts: total attempts (including first)
    backoff_factor: base seconds to wait; delay = backoff_factor * (2 ** (retry_count-1))
    max_delay: cap for delay
    exceptions: tuple of exception classes to catch and retry on
    jitter: whether to add random jitter up to 25% of delay
    """
    def deco(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            last_exc = None
            for attempt in range(1, attempts + 1):
                try:
                    return fn(*args, **kwargs)
                except exceptions as e:
                    last_exc = e
                    if attempt == attempts:
                        logger.debug("Retry: final attempt failed (%s): %s", fn.__name__, e)
                        raise
                    else:
                        delay = backoff_factor * (2 ** (attempt - 1))
                        if jitter:
                            delay = delay * (1 + random.uniform(-0.25, 0.25))
                        if delay > max_delay:
                            delay = max_delay
                        logger.debug("Retry: attempt %s/%s failed for %s: %s — sleeping %.2fs", attempt, attempts, fn.__name__, e, delay)
                        time.sleep(delay)
            # if we exit loop without returning, re-raise last exception
            if last_exc:
                raise last_exc
        return wrapper
    return deco


def retry_call(fn, attempts=DEFAULT_ATTEMPTS, backoff_factor=DEFAULT_BACKOFF, max_delay=DEFAULT_MAX_DELAY, exceptions=(Exception,), jitter=True, *args, **kwargs):
    """Call a function with retry behaviour; returns its result or raises the last exception."""
    last_exc = None
    for attempt in range(1, attempts + 1):
        try:
            return fn(*args, **kwargs)
        except exceptions as e:
            last_exc = e
            if attempt == attempts:
                logger.debug("retry_call: final attempt failed for %s: %s", getattr(fn, '__name__', str(fn)), e)
                raise
            delay = backoff_factor * (2 ** (attempt - 1))
            if jitter:
                delay = delay * (1 + random.uniform(-0.25, 0.25))
            if delay > max_delay:
                delay = max_delay
            logger.debug("retry_call: attempt %s/%s failed for %s: %s — sleeping %.2fs", attempt, attempts, getattr(fn, '__name__', str(fn)), e, delay)
            time.sleep(delay)
    if last_exc:
        raise last_exc


if __name__ == '__main__':
    # simple demo
    @retry(attempts=4, backoff_factor=0.5)
    def test_bad(x):
        if random.random() < 0.8:
            raise ValueError('random fail')
        return x * 2

    try:
        print(test_bad(10))
    except Exception as e:
        print('Final failure:', e)
